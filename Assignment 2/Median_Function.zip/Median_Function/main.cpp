//Alex Castillo		         CSC17A		       Chapter 9, P.545, #9
//
/**************************************************************************
 * 
 * Find the Median
 * 
 * _____________________________________________________________
 * This program uses pointer notation to determine the median
 * of an already sorted array uses an array of integers and an
 * integer that determines the amount of elements in the array.
 * _____________________________________________________________
 * INPUT
 *  medSize               : Size of the median array
 *  medArry[medSize]
 * OUTPUT
 *  median
 *************************************************************************/
#include <iostream>
using namespace std;

int findMed (int *, int);

int main(int argc, char** argv) 
{
    int medSize;      // Find out array size
    
    cout << "What size would you like the array to be? ";
    cin >> medSize;
    cout << endl << endl;
    
    int medArry[medSize];    // Initialize array with user defined amount
    int median;
    
    // Input
    cout << "Please enter, in ascending order, the values of the median array\n";
    for(int index = 0; index < medSize; index++)
    {
        cout << "Value #" << index+1 << ": ";
        cin >> medArry[index];
        
    }
    
    median = findMed(medArry, medSize);
    
    cout << "The median of the array is: " << median << endl;

    return 0;
}


int findMed (int *arry, int arySize)
{
    int median;
    if (arySize % 2 == 0)
	{
		median = (*(arry + (arySize/2)) + *(arry + (arySize/2+1)))/2;
	}
	else
	{
		median = *(arry + (arySize/2));
	}
	return median;
}