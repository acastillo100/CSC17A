//Alex Castillo		    CSC17A	       Chapter 9, P.545, #5
//
/******************************************************************
 * 
 * USE POINTER ALLOCATION
 * ________________________________________________________________
 * This program rewrites a function so it uses pointers instead
 * of reference variables.
 * ________________________________________________________________
 * INPUT
 *  Values for X and Y 
 * 
 * OUTPUT
 *   x			:Display value for x
 *   y			:Display value for y
 *****************************************************************/
#include <iostream>
#include <string>
using namespace std;
 
int doSomething(int *X, int *Y);
 
int main() 
{
	int X = 10;	
	int Y = 5;	
 
	cout << "This is the X value before the function call: " << X << endl;
	cout << "This is the Y value before the function call: " << Y << endl;
 
	//Function call
	cout << "Result: " << doSomething (&X, &Y) << endl;
	cout << "X value after function call: " << X << endl;
	cout << "Y value after function call: " << Y << endl;
 
	return 0;
}
 
//Function using pointers
int doSomething (int *X, int *Y)
{
	int temp = *X;
	*X = *Y * 10;
	*Y = temp * 10;
	return *X + *Y;
}