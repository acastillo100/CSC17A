//Alex Castillo       	    CSC17A	       Chapter 9, P.546, #10
//
/*******************************************************************
 * 
 * DISPLAY REVERSE ARRAY ORDER
 * _________________________________________________________________
 * This program has a function that accepts an int array
 * and the array's size as arguments, then creates a copy in
 * reversed order. The function will then return a pointer to the
 * new array.
 * ________________________________________________________________
 * INPUT
 *   number				:Elements in the array
 * 
 * OUTPUT
 *   reversed_array	                :Array in reversed order
 ******************************************************************/
#include <iostream>
using namespace std;
 
int *revArry(int numArry[], int arrySize);
 
int main() 
{
//	const int SIZE = 10;       // Size of array
        int size;
        
        cout << "Enter how many integers needed for the array: ";
        cin >> size;
        cout << endl;
        
	int number[size];          // Array of ints
	int *bkwdAry;              // Pointer array to hold the reversed array                  
 
	cout << "Enter " << size << " integers for the array: " << endl;
 
	for (int i = 0; i < size; i++)
		cin >> number[i];
	cout << "Elements in the original array: ";
 
	for (int i = 0; i < size; i++)
		cout << number[i] << " ";
		cout << endl;
 
	//Function call the reversed array
	bkwdAry = revArry(number, size);
	cout << "Elements in the reversed array: ";
 
	for (int i = 0; i < size; i++)
		cout << bkwdAry[i] << " ";
		cout << endl;
	return 0;
}
 
//Function definition
int *revArry(int numArry[], int arrySize)
{
	int *newArry;
	newArry = new int[arrySize];
	int x = 0;
 
	for (int i = arrySize - 1; i >= 0; i--)
	{
		newArry[x] = numArry[i];
		x++;
	}
	return newArry;
}