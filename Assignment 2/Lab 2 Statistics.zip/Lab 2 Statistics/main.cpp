/* 
 * File:   main.cpp
 * Author: Alex Castillo
 * Created on Sept 24th, 2017, 11:10 PM
 * Purpose:  Calculate mean, median and mode from a random array
 */

//System Libraries
#include <iostream>         // The Input and Output Library
#include <cstdlib>          //Randomly creates numbers
#include <ctime>            // Time library to create seeds
using namespace std;

int main(int argc, char** argv) 

{
    //
    void *getArray(int*, int);
    void prntArray(int*, int);
    int sortAry(int*,int);
    float calcMedian(int*,int);
    float calcMean(int *, int);
    float calcMode(int *, int);
    int modeSrch(int *, int, float);
    
    // Seeds the random number function alongside time
//    srand(static_cast<unsigned int>(time(0)));
    
    //Declare and initialize Variables
    int arySize;                        // Size of the array 
    int *numArray;                      // The array holding numbers
    float median;                       // The median of the array
    float mean;                         // The mean of the array
    float mode;                         // The mode of the array
    int reptMode;                       // Number of times the mode appears
    int index;
    
    cout << "What size do you want the array to be? ";
    cin >> arySize;
       
    // Create the new array
	numArray = new int[arySize];
    
    getArray(numArray,arySize);
    
    cout << endl << endl;
    
    prntArray(numArray, arySize);
    
    sortAry(numArray, arySize);
    
    prntArray(numArray, arySize);
    
    median = calcMedian(numArray, arySize);
    
    mean = calcMean(numArray, arySize);
    
    mode = calcMode(numArray, arySize);
    
    reptMode = modeSrch(numArray, arySize, mode);
    
    cout << "This is the median of the array: " << median << endl;
    
    cout << "This is the mean of the array: " << mean << endl;
    
    cout << "This is the mode of the array: " << mode << endl;
    
    cout << "This is the amount of times the mode appears: " << reptMode << endl;

    return 0;
}

void getArray(int *array, int size)
{
    cout << "Please enter the set of numbers you want ";
	for (int i = 0; i < size; i++)
	{
        cout << "#" << i + 1 << ": ";
        cin >> *(array + i);
        cout << " ";
	}
}

//Prints the array
void prntArray(int*ary, int n)
{
    for(int i=0;i<n;i++)
    {
        cout << ary[i] <<" ";
    }
    cout<<endl;
}

//Uses a sort to change the array from the lowest to highest numbers.
int sortAry(int *a,int b)
{
    int startScan;
    int minIndex;
    int minValue;
 
    for (startScan = 0; startScan < (b - 1); startScan++)
    {
        minIndex = startScan;
        minValue = *(a + startScan);
        for (int index = startScan + 1; index < b; index++)
        {
            if (*(a + index) < minValue)
            {
                minValue = *(a + index);
                minIndex = index;
            }
        }
 
        *(a + minIndex) = *(a + startScan);
        *(a + startScan) = minValue;
    }
  }

//Calculates the median of the array by checking if the array is <=0, even or odd
// and returning the median value.
float calcMedian(int *aValues,int num)
{
    if(num <= 0) 
        return 0;
    
    if(num % 2 !=0) 
    {
        return (float)aValues[(((num+1)/2)-1)];
    }
        
    
    else
    {
        int pos = num / 2;
        return (float) ((aValues[pos] + aValues[pos+1]) / 2);
    }
}

//Calculates the mean of the array by adding the numbers in the array into
//totSum so they can be divided by the total number of the array
float calcMean(int *aValues, int num) 
{
    float totSum = aValues[0];
    for (int i = 1; i < num; ++i) 
    {
        totSum += aValues[i];
    }
    return totSum/num;
}

// This function calculates the mode of the array by creating a new int array
// and searching for the number within the array that repeats the most
float calcMode(int *aValues, int num) 
{
    // Allocate a new int array of the same size to hold same array
    int* arryRep = new int[num];
    
    int index = 1;
        int max = 0;
        for (int i = 0; i < num - 1; i++)
        {
           if ( aValues[i] == aValues[i+1] )
           {
              index++;
              if ( index > max )
              {
                  max = index;
                  return aValues[i];
              }
           } else
              index = 1; // reset counter.
        }
    
        cout << "There is no mode." << endl;
        return 0;
}

// The mode function but instead of returning the mode it returns the number
// of times the mode appears in the array
int modeSrch(int *aValues, int num, float mode)
{
    int res = 0;
    for (int i=0; i<num; i++)
        if (mode == aValues[i])
          res++;
    return res;
}