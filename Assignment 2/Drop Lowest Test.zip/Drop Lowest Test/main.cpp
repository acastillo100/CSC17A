//Alex Castillo		         CSC17A		       Chapter 9, P.544, #2
//
/**************************************************************************
 * 
 * OBTAIN/SORT SCORES, CALCULATE THE AVERAGE, AND DISPLAY
 * RESULTS
 * _____________________________________________________________
 * This program let the user enter test scores, then the program
 * sorts the scores, calculates the average score, and finally 
 * displays the scores. It also dynamically allocates memory for 
 * the test scores.
 * _____________________________________________________________
 * INPUT
 *  Test Scores
 * 
 * OUTPUT
 *  Sorted Test Scores
 *  Average test scores
 *************************************************************************/
 
 #include <iostream>
 #include <iomanip>
 using namespace std;
 
 void GetTestScores(int *testArray, int size);
 void SelectionSort(int *testArray, int size);
 float CalculateAverage(int *testArrayy, int size);
 void DisplayArray(int *testArray, int size);
 
int main ()
{
    int size = 0;  // Size of the array
    int *testArray; // Pointer to the array
    bool keepLoop; // Loop controller
    float average; // Average of all the test scores
 
    // Ask the user for the number of test scores
    do
    {
        cout << "How many test scores you are going to enter? ";
        cin >> size;
        keepLoop = size < 2;  // Makes sure that the size of the array is
                                 // more than two
        if (keepLoop)
            cout << "\nThe number of test scores must be at least 2!\n";
    } while (keepLoop);
    cout << endl;
 
	// Create the new array
	testArray = new int[size];
 
	// Let the user enter the test scores
	GetTestScores(testArray, size);
 
	// Sort the array
	SelectionSort(testArray, size);
 
	// Calculate the average
	average = CalculateAverage(testArray, size);
 
	// Display the array
	cout << endl;
	cout << "Here are the test scores sorted";
	cout << endl;
	DisplayArray(testArray, size);
 
	// Display the average
	cout << setprecision(2) << fixed;
	cout << "\nThe average score is: " << average << endl;
        cout << " (It does not include the lowest score [" << *testArray << "])";
        
        delete [] testArray;
 
    return 0;
}
 
 
void GetTestScores(int *testArray, int size)
{
	cout << "Please enter the test scores ";
	for (int i = 0; i < size; i++)
	{
        cout << "#" << i + 1 << ": ";
        cin >> *(testArray + i);
        cout << " ";
	}
}
 
float CalculateAverage(int *testArray, int size)
{
	float Total = 0;   // Total score
	float Average;
 
        // Starts with 1 to drop lowest test score
	for (int i = 1; i < size; i++)
        Total += *(testArray + i);     
 
    // Calculate the average 
    Average = Total / (size - 1);
 
	return Average;
}
 
 
void DisplayArray(int *testArray, int size)
{
	for (int i = 0; i < size; i++)
	{
        cout << *(testArray + i);
        if (i < size - 1)
            cout << ", ";
	}
}
 
 
void SelectionSort(int *testArray, int size)
{
    int startScan;
    int minIndex;
    int minValue;
 
    for (startScan = 0; startScan < (size - 1); startScan++)
    {
        minIndex = startScan;
        minValue = *(testArray + startScan);
        for (int index = startScan + 1; index < size; index++)
        {
            if (*(testArray + index) < minValue)
            {
                minValue = *(testArray + index);
                minIndex = index;
            }
        }
 
        *(testArray + minIndex) = *(testArray + startScan);
        *(testArray + startScan) = minValue;
    }
}