//Alex Castillo                 CSC17A                 Chapter 14, P.884, #4
//
/***************************************************************************
* DISPLAY HOURS
* __________________________________________________________________________
* This program creates a class called NumDays. The class’s purpose is to store 
* a value that represents a number of work hours and convert it to a number 
* of days. For example, 8 hours would be converted to 1 day, 12 hours would be 
* converted to 1.5 days, and 18 hours would be converted to 2.25 days. The class 
* should have a constructor that accepts a number of hours, as well as member 
* functions for storing and retrieving the hours and days.
* 
* **************************************************************************
* INPUT
* num                  : Number that user inputs
* 
* 
* OUTPUT
* 
* days.print()         : Class void function that outputs the days and hours                      
* __________________________________________________________________________
****************************************************************************/
#include <iostream>
#include <iomanip>
#include "NumDays.h"

using namespace std;

int main()
{
    //Initialize variables
    NumDays days;
    NumDays daysTwo;
    int num;   
    
    //Accept User Input   
        cout << "Please enter the number of hours (>0) worked: ";
        cin >> num;
        days.setHrs(num);
        days.setDays(num);
        
        //Input Validation
        while (num < 0)
        {
            do{
            cout << "\nThat is not a valid number. Please enter a number that is"
                 << " greater than or equal to 0: ";
            cin >> num;
            }while(num < 0);
        }
    
    cout << endl;
    daysTwo = days;
    
   //Output the number in English
    days.print();
    
    // Make day the next day in the year (Prefix)
    ++days;    
    num = days.getHrs();
    days.setHrs(num);
    
    cout << endl;
    
    cout << "These are the hours and days incremented: ";
    
    days.print();  // print the following day 
    
    //Add the previous day with the original
    days+daysTwo;
    
    cout << endl;
    
    cout << "These are the hours and days of the previous and the original "
            "added together: ";
    
    days.print();  // print the following day
    
    //Subtract the previous day with the original
    days-daysTwo;
    
    cout << endl;
    
    cout << "These are the hours and days of the previous and the original "
            "subtracted together: ";
    
    days.print();  // print the following day
    
    // Make day the next day in the year (Postfix)
    days++;
    num = days.getHrs();
    days.setHrs(num);
    
    cout << "\nThese are the hours and days incremented: ";
    
    days.print();  // print the following day 
    
    // Make day the previous day in the year (Prefix)
    --days;    
    num = days.getHrs();
    days.setHrs(num);
    
    cout << endl;
    
    cout << "These are the hours and days decremented: ";
    
    days.print();  // print the following day 
    
    // Make day the previous day in the year (Postfix)
    days--;
    num = days.getHrs();
    days.setHrs(num);
    
    cout << "\nThese are the hours and days decremented: ";
    
    days.print();  // print the following day

   return 0;
}