/* 
 * File:   Day.cpp
 * Author: Alex
 *
 * Created on November 14, 2017, 8:00 PM
 */

#include <iostream>
#include <cmath>
#include "NumDays.h"
using namespace std;


void NumDays::print()
{
    cout << "\nThis is the number of hours worked: " << getHrs();
    cout << "\nThis is the number of days worked: " << getDays();
    cout << endl;
}