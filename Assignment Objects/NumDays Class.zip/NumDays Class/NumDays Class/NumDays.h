/* 
 * File:   NumDays.h
 * Author: Alex
 *
 * Created on November 14, 2017, 8:00 PM
 */

#ifndef NUMDAYS_H
#define NUMDAYS_H

#include <string>

class NumDays
{
private:
    int hours;
    float days;
    
public: 
    NumDays()
    {
        hours = 0;
        days = 4.0;
    }
    
    NumDays(int numHrs)
    {
        numHrs = hours;
    }
    
    NumDays operator++()
    {
        hours += 4;
        days = 4.0;
        static_cast<float>(hours);
        days = hours/days;
        return *this;
    }
    
    NumDays operator++(int)
    {
        hours += 4;
        days = 4.0;
        days = hours/days;
        return *this;
    }
    
    NumDays operator+(NumDays &One)
    {
        hours = One.hours + hours;
        days = days + One.days;
        return *this;
    }
    
    NumDays operator-(NumDays &One)
    {
        hours = hours - One.hours;
        days = days - One.days;
        return *this;
    }
    
    NumDays operator--()
    {
        hours -= 4;
        days = 4.0;
        days = hours/days;
        return *this;
    }
    
    NumDays operator--(int)
    {
        hours -= 4;
        days = 4.0;
        days = hours/days;
        return *this;
    }
    
    void setHrs(int numHrs){(numHrs >= 0); hours = numHrs;}
    void setDays(int numHrs){(static_cast<float> (numHrs)); days = numHrs/days;}
    int getHrs() {return hours;}
    float getDays() {return days;}
    void print();

};

#endif /* DAYSMOD_H */