/* 
 * File:   Day.cpp
 * Author: Alex
 *
 * Created on November 14, 2017, 6:00 PM
 */

#include <iostream>
#include <cmath>
#include "DaysMod.h"
using namespace std;


void DayOfYear::print(int num)
{


	static string dayNums[32] = { " ", "1", "2", "3", "4", "5", "6", "7", "8",
		                      "9", "10", "11", "12", "13", "14", "15", 
                                      "16", "17", "18", "19", "20", "21", "22",
                                      "23", "24", "25", "26", "27", "28", "29",
                                      "30", "31"};

	static string months[] = { "January", "February", "March", "April", "May", 
                                 "June", "July", "August", "September", "October", 
                                 "November", "December"};


	if (num <= 31)
        {
		cout << months[0] << dayNums[0] << dayNums[num];
        }        
        else if (num > 31 && num <= 59)
        {
		cout << months[1] << dayNums[0] << dayNums[num-31];
        }        
        else if (num > 59 && num <= 90)
        {
		cout << months[2] << dayNums[0] << dayNums[num-59];
        }        
        else if (num > 90 && num <= 120)
        {
		cout << months[3] << dayNums[0] << dayNums[num-90];
        }       
        else if (num > 120 && num <= 151)
        {
		cout << months[4] << dayNums[0] << dayNums[num-120];
        }
        else if (num > 151 && num <= 181)
        {
		cout << months[5] << dayNums[0] << dayNums[num-151];
        }
        else if (num > 181 && num <= 212)
        {
		cout << months[6] << dayNums[0] << dayNums[num-181];
        }
        else if (num > 212 && num <= 243)
        {
		cout << months[7] << dayNums[0] << dayNums[num-212];
        }
        else if (num > 243 && num <= 273)
        {
		cout << months[8] << dayNums[0] << dayNums[num-243];
        }
        else if (num > 273 && num <= 304)
        {
		cout << months[9] << dayNums[0] << dayNums[num-273];
        }
        else if (num > 304 && num <= 334)
        {
		cout << months[10] << dayNums[0] << dayNums[num-304];
        }
        else
        {
		cout << months[11] << dayNums[0] << dayNums[num-334];
        }
}

