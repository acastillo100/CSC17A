//Alex Castillo                 CSC17A                 Chapter 14, P.884, #3
//
/***************************************************************************
* DISPLAY DAY
* __________________________________________________________________________
* This program creates a class that translate whole dollar amounts in the range
* 0 through 9999 into an English description of the number. 713 would be 
* translated into the string seven hundred thirteen, and 8203 would be
* translated into eight thousand two hundred three. It uses a single integer
* member variable and a static array of string objects that specify how to 
* translate key dollar amounts into the desired format.
* 
* **************************************************************************
* INPUT
* num                  : Number that user inputs
* 
* 
* OUTPUT
* 
* integer.print        : Numbers class void function that outputs the user
*                      : inputed number to English
* __________________________________________________________________________
****************************************************************************/
#include <iostream>
#include <iomanip>
#include "DaysMod.h"

using namespace std;

int main()
{
    //Initialize variables
    DayOfYear days;
    int num;   
    
    //Accept User Input   
        cout << "Please enter a number (0-365) to be displayed in full: ";
        cin >> num;
        days.setNumber(num);
        
        //Input Validation
        while (num < 0 || num > 9999)
        {
            do{
            cout << "\nThat is not a valid number. Please enter a number that is"
                 << " from 0 to 365: ";
            cin >> num;
            }while(num < 0 || num > 365);
        }
    
    cout << endl;
    
   //Output the number in English
    days.print(num);
    
    // Make day the next day in the year (Prefix)
    ++days;    
    num = days.getNumber();
    
    cout << endl;
    
    cout << "This is the date incremented: ";
    
    days.print(num);  // print the following day 
    
    // Make day the next day in the year (Postfix)
    days++;
    num = days.getNumber();
    
    cout << "\nThis is the date incremented: ";
    
    days.print(num);  // print the following day 
    
    // Make day the previous day in the year (Prefix)
    --days;    
    num = days.getNumber();
    
    cout << endl;
    
    cout << "This is the date decremented: ";
    
    days.print(num);  // print the following day 
    
    // Make day the previous day in the year (Postfix)
    days--;
    num = days.getNumber();
    
    cout << "\nThis is the date decremented: ";
    
    days.print(num);  // print the following day

   return 0;
}