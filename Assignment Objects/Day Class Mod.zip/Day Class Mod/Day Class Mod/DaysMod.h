/* 
 * File:   DaysMod.h
 * Author: Alex
 *
 * Created on November 14, 2017, 6:00 PM
 */

#ifndef DAYSMOD_H
#define DAYSMOD_H

#include <string>

class DayOfYear
{
private:
    int day;
    
public: 
    DayOfYear()
    {
        day = 0;
    }
    
    DayOfYear(int numDay)
    {
        numDay = day;
    }
    
    DayOfYear operator++()
    {
        if (day == 365)
        day = 1;
        else
        day++;
        return *this;
    }
    
    DayOfYear operator++(int)
    {
        if (day == 365)
        day = 1;
        else
        day++;
        return *this;
    }
    
    DayOfYear operator--()
    {
        if (day == 1)
            day = 365;
        else
            day--;
        return *this;
    }
    
    DayOfYear operator--(int)
    {
        if (day == 1)
            day = 365;
        else
            day--;
        return *this;
    }
    
    void setNumber(int numDay){(numDay >= 0); day = numDay;}   
    int getNumber() {return day;}
    void print(int numDay);

};

#endif /* DAYSMOD_H */

