/* 
 * File:   Essay.h
 * Author: Alex
 *
 * Created on November 15, 2017, 8:10 PM
 */

#ifndef ESSAY_H
#define PASSFAILACTIVITY_H

#include "GradedActivity.h"

class Essay:public GradedActivity
 {
 protected:
     float grammer;
     float spelling;
     float length;
     float content;
     
public:
      // Default constructor
     Essay():GradedActivity()
     {grammer = 0.0;
      spelling = 0.0;
      length = 0.0;
      content = 0.0;
     }
     // Constructor
     Essay(float gram, float spell, float len, float cont):GradedActivity()
     {grammer = gram;
      spelling = spell;
      length = len;
      content = cont;}
     // Mutator functions
    void setGram(float gram)
    {grammer = gram;}
    void setSpell(float spell)
    {spelling = spell;}
    void setLength(float len)
    {length = len;}
    void setContent(float cont)
    {content = cont;}

    // Accessor functions
    float getGram() const
    {return grammer;}
    float getSpell() const
    {return spelling;}
    float getLength() const
    {return length;}
    float getContent() const
    {return content;}   
 };
#endif /* ESSAY_H */