//Alex Castillo                 CSC17A                 Chapter 15, P.965, #6
//
/***************************************************************************
* DISPLAY ESSAY GRADE
* __________________________________________________________________________
* This program designs an Essay class that is derived from the GradedActivity 
* class presented in this chapter. The Essay class determines the grade a student 
* receives on an essay. The student’s essay score can be up to 100, and is 
* determined in the following manner: Grammar: 30 points, Spelling: 20 points,
* Correct length: 20 points, Content: 30 points.
* 
* **************************************************************************
* INPUT
* 
* one	        : One variable of the Essay class (Holds scores of all 4 areas)
* 
* OUTPUT
* 
* total         : Total points obtained by the user
* percent       : Total percentage of the grade
* 
* __________________________________________________________________________
****************************************************************************/

#include <iostream>
#include <iomanip>
#include "Essay.h"

// Function prototype
 void displayGrade(Essay &,GradedActivity &);

using namespace std;

int main(int argc, char** argv) 
{
 Essay one;
 GradedActivity score;
 float gram, spell, length, content;
 
 do
 {
    cout << "Please enter your essay score in the grammar category (0-30): ";
    cin >> gram;
 }while(gram < 0 || gram > 30);
 one.setGram(gram);
 
 do 
 {
    cout << "\nPlease enter your essay score in the spelling category (0-20): ";
    cin >> spell;
 }while (spell < 0 || spell > 20);
 one.setSpell(spell);
 
 do 
 {
    cout << "\nPlease enter your essay score in the length category (0-20): ";
    cin >> length;
 }while (length < 0 || length > 20);
 one.setLength(length);
 
 do
 {
    cout << "\nPlease enter your essay score in the content category (0-30): ";
    cin >> content;
 }while(content < 0 || content > 30);
 one.setContent(content);

 // Display the object's grade data.
 displayGrade(one,score);

    return 0;
}

void displayGrade(Essay &one, GradedActivity &score)
{
    float total, percent;
    total = one.getGram() + one.getSpell() + one.getLength() + one.getContent();
    score.setScore(total);
    percent = (total / 100) * 100;
    cout << setprecision(2) << fixed;
    cout << "\nThe total essay score out of 100 is: " << score.getScore();
    cout << "\nThe percentage of the grade comes out to: " << percent << "%.";
}