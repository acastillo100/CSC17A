//Alex Castillo                 CSC17A                 Chapter 15, P.964, #2
//
/***************************************************************************
* DISPLAY SUPERVISOR INFO
* __________________________________________________________________________
* This program creates a class named Employee. The class should keep the following 
* information of an employee name, employee number, and hire date.  It creates 
* constructors and the appropriate accessor and mutator functions for the class. 
* Then it writes a class named the ShiftSupervisor class and has a member variable 
* that holds the annual salary and a member variable that holds the annual 
* production bonus that a shift supervisor has earned.
* 
* **************************************************************************
* INPUT
* name                          : Name of new employee
* info                          : Info of new employee (Employee #, date, shift)
* pay                           : Hourly rate
* anSal                         : Annual Salary for ShiftSupervisor
* aPBonus                       : Annual Production Bonus for ShiftSupervisor
* 
* 
* OUTPUT
* 
* super.get_           : Displays the info of the Supervisor
* __________________________________________________________________________
****************************************************************************/

#include "Employee.h"
#include <string>
#include <iostream>
using namespace std;

int main(int argc, char** argv) 
{
    ProductionWorker sorter("Alex", 9102, 19051998, 1, 12.5);
    cout << sorter.getName() << " is the worker with the title of sorter." 
         << "\nHis employee # is: " << sorter.getNum()
         << "\nHe was hired on (D/M/Y): " << sorter.getDate()
         << "\nHe works the " << sorter.getShft() << " shift."
         << "\n,He gets paid $" << sorter.getPayRt() << " per hour.";
    
    ProductionWorker worker;
    ShiftSupervisor super;
    string name;
    int info;
    float pay;
    float anSal;
    float aPBonus;
    
    cout << "\n\nPlease input the new worker's information:" << endl;
    cout << "What is his name: ";
    cin >> name;
    worker.setName(name);
    cout << "\nWhat is his employee number (####): ";
    cin >> info;
    worker.setNum(info);
    cout << "\nWhen was he hired (D/M/Y): ";
    cin >> info;
    worker.setDate(info);
    cout << "\nWhich shift does he work? (1=Day, 2=Night): ";
    cin >> info;
    worker.setShft(info);
    cout << "\nWhat is his hourly wage: $";
    cin >> pay;
    worker.setPayRt(pay);
    //Display info
    cout << endl << worker.getName() << " is the new worker."
         << "\nHis employee # is: " << worker.getNum()
         << "\nHe was hired on (YYYYMMDD): " << worker.getDate()
         << "\nHe works the " << worker.getShft() << " shift."
         << "\nHe gets paid $" << worker.getPayRt() << " per hour.\n\n";
    
    //Info for ShiftSupervisor
    cout << "\n\nPlease input the Shift Supervisor's information:" << endl;
    cout << "What is their name: ";
    cin >> name;
    super.setName(name);
    cout << "\nWhat is his employee number (####): ";
    cin >> info;
    super.setNum(info);
    cout << "\nWhen was he hired (D/M/Y): ";
    cin >> info;
    super.setDate(info);
    cout << "\nWhat is the annual salary the supervisor has earned?: ";
    cin >> anSal;
    super.setAnnualSalary(anSal);
    cout << "\nWhat is the annual production bonus the supervisor has earned?: ";
    cin >> aPBonus;
    super.setABonusSalary(aPBonus);
    //Display info
    cout << endl << super.getName() << " is the supervisor."
         << "\nTheir employee # is: " << super.getNum()
         << "\nThey was hired on (YYYYMMDD): " << super.getDate()
         << "\nTheir annual salary is $" << super.getAnnualSalary() << " ."
         << "\nTheir annual production bonus is $" << super.getABonusSalary() << " .\n\n";  
    return 0;
}