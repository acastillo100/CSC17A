/* 
 * File:   Numbers.h
 * Author: Alex
 *
 * Created on November 13, 2017, 11:10 PM
 */

#ifndef NUMBERS_H
#define NUMBERS_H

#include <string>

class Numbers
{
private:
    int number;
//    static std::string lessThan20[20] = {"zero", "one", "two", "three", "four",
//                                         "five", "six", "seven", "eight", "nine",
//                                         "ten", "eleven", "twelve", "thirteen",   
//                                         "fourteen", "fifteen", "sixteen",
//                                         "seventeen", "eighteen", "nineteen"};
//    static std::string tens[] = {"zero", "Ten", "Twenty", "Thirty", "Forty", 
//                                 "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };
//    static std::string hundreds = { " ", "Hundred" };
//    static std::string thousands = { " ", "Thousand" };
    
public: 
    Numbers()
    {
        number = 0;
    }
    
    Numbers(int gNumber)
    {
        gNumber = number;
    }
    
    void setNumber(int gNumber){(gNumber >= 0); number = gNumber;}   
    int getNumber() {return number;}
//    void print(int gNumber);
    void print(int gNumber);

};

#endif /* PAYROLL_H */

