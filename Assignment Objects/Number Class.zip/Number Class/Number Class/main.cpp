//Alex Castillo                 CSC17A                 Chapter 14, P.884, #1
//
/***************************************************************************
* DISPLAY WRITTEN NUMBER
* __________________________________________________________________________
* This program creates a class that translate whole dollar amounts in the range
* 0 through 9999 into an English description of the number. 713 would be 
* translated into the string seven hundred thirteen, and 8203 would be
* translated into eight thousand two hundred three. It uses a single integer
* member variable and a static array of string objects that specify how to 
* translate key dollar amounts into the desired format.
* 
* **************************************************************************
* INPUT
* num                  : Number that user inputs
* 
* 
* OUTPUT
* 
* integer.print        : Numbers class void function that outputs the user
*                      : inputed number to English
* __________________________________________________________________________
****************************************************************************/
#include <iostream>
#include <iomanip>
#include "Numbers.h"

using namespace std;

int main()
{
    //Initialize variables
    Numbers integer;
    int num;   
    
    //Accept User Input   
        cout << "Please enter a number (0-9999) to be displayed into English: ";
        cin >> num;
        integer.setNumber(num);
        
        //Input Validation
        while (num < 0 || num > 9999)
        {
            do{
            cout << "\nThat is not a valid number. Please enter a number that is"
                 << " from 0 to 9999: ";
            cin >> num;
            }while(num < 0 || num > 9999);
        }
    
    cout << endl;
    
   //Output the number in english
    integer.print(num);

   return 0;
}