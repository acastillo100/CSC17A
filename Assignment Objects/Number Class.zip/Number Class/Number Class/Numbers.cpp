/* 
 * File:   Numbers.cpp
 * Author: Alex
 *
 * Created on November 13, 2017, 11:30 AM
 */

#include <iostream>
#include <cmath>
#include "Numbers.h"
using namespace std;


void Numbers::print(int num)
{
    int n;
//    int num;


	static string lessThanTwenty[20] = { " ", "One", "Two", "Three", "Four", 
                                             "Five", "Six", "Seven", "Eight",
		                             "Nine", "Ten", "Eleven", "Twelve", 
                                             "Thirteen", "Fourteen", "Fifteen", 
                                             "Sixteen", "Seventeen", "Eighteen", 
                                             "Nineteen" };

	static string tens[] = { "zero", "Ten", "Twenty", "Thirty", "Forty", 
                                 "Fifty", "Sixty", "Seventy", "Eighty", 
                                 "Ninety" };

	static string hundreds = " Hundred " ;

	static string thousands = " Thousand ";

	if (num < 0)
		cout << "Number is a negative number. Please enter a number between 0-9999.";
	num = abs(num);
	n = num / 1000;

	if (n>0)
		cout << lessThanTwenty[n] << thousands;
	num %= 1000;
	n = num / 100;

	if (n > 0)
		cout << lessThanTwenty[n] << hundreds;
	num %= 100;
	if (num >= 20)
	{
		n = num / 10;
		if (n > 0)
			cout << tens[n] << " ";
	}
	else if (num >= 10)
	{
		cout << lessThanTwenty[num] << " ";

		return;
	}
	num %= 10;
	if (num > 0)
		cout << lessThanTwenty[num];
	cout << " ";
}

