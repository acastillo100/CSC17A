/* 
 * File:   ClassDate.h
 * Author: Alex
 *
 * Created on October 16, 2017, 8:10 AM
 */

#ifndef CLASSDATE_H
#define CLASSDATE_H
#include <string>
#include <stdlib.h>

class Date
{
private:
    int month, day, year;
    std::string exMonth;
    
public: 
    
    Date()
    {
        month = 0;
        day = 0;
        year = 0;
    }
    
    Date(int mth, int days, int yr)
    {
        mth = month;
        days = day;
        yr = year;
        
    }
    
    Date operator++()
    {
        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 ||
            month == 10 || month == 12)
        {
            if (day == 31)
                day = 1;
            else
                abs(day++);
        }
        
        if (month == 4 || month == 6 || month == 9 || month == 11)
        {
            if (day == 30)
                day = 1;
            else
                abs(day++);
        }
        
        if (month == 2)
        {
            if (day == 28)
                day = 1;
            else
                abs(day++);
        }
        return *this;
    }
    
    Date operator++(int)
    {
        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 ||
            month == 10 || month == 12)
        {
            if (day == 31)
                day = 1;
            else
                day++;
        }
        
        if (month == 4 || month == 6 || month == 9 || month == 11)
        {
            if (day == 30)
                day = 1;
            else
                day++;
        }
        
        if (month == 2)
        {
            if (day == 28)
                day = 1;
            else
                day++;
        }
        return *this;
    }
    
    Date operator--()
    {
        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 ||
            month == 10 || month == 12)
        {
            if (day == 1)
                day = 31;
            else
                day--;
        }
        
        if (month == 4 || month == 6 || month == 9 || month == 11)
        {
            if (day == 1)
                day = 30;
            else
                day--;
        }
        
        if (month == 2)
        {
            if (day == 1)
                day = 28;
            else
                day--;
        }
        return *this;
    }
    
    Date operator-(Date &One)
    {
        day = abs(day - One.day);
        return *this;
    }
    
    Date operator--(int)
    {
        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 ||
            month == 10 || month == 12)
        {
            if (day == 1)
                day = 31;
            else
                day--;
        }
        
        if (month == 4 || month == 6 || month == 9 || month == 11)
        {
            if (day == 1)
                day = 30;
            else
                day--;
        }
        
        if (month == 2)
        {
            if (day == 1)
                day = 28;
            else
                day--;
        }
        return *this;
    }
    
    void setDay(int days){(days > 0); day = days;}
    int getDay() {return day;}
    void setMth(int mth){(mth > 0); month = mth;}
    void DisOne(int, int, int);
    void DisTwo(std::string month, int, int);
    void DisThree(std::string month, int, int);   
};



#endif /* CLASSDATE_H */