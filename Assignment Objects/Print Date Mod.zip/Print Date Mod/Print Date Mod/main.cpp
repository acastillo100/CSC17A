//Alex Castillo                 CSC17A                 Chapter 14, P.887, #8
//
/***************************************************************************
* DISPLAY DATE WITH CLASS
* __________________________________________________________________________
* This program designs a class called Date. The class stores a date in three 
* integers: month , day , and year. There are member functions to print the 
* date in the following forms: 12/25/2014, December 25, 2014, and 
* 25 December 2014. Now includes prefix and postfix increment operators, 
* prefix and postfix decrement operators, and a subtraction operator.
* 
* **************************************************************************
* INPUT
* 
* mth	        : Month submitted by the user
* day		: Day submitted by the user
* year          : Year submitted by the user
* 
* OUTPUT
* 
* displayOne/Two/Three           : Input three formatted different ways
* 
* __________________________________________________________________________
****************************************************************************/
#include <iostream>
#include <string>
#include "ClassDate.h"

using namespace std;

int main()
{
    //Initialize variables
    Date display;
    Date displayS;
    int mth, day, year;
    string monName;
    
    
    //Accept User Input
    cout << "Please enter the month (1-12): ";
    cin >> mth;
    cout << endl;
    
    //Input Validation
    do
        if (mth > 12 || mth < 1)
        {
            cout << "Please enter another month 1-12: ";
            cin >> mth;
        }
    while (mth > 12 || mth < 1);
    display.setMth(mth);
        
        //Switch statement to assign month number with month name
         switch(mth)
        {
                case 1: monName = "January";
                        break;
                case 2: monName = "February";
                        break; 
                case 3: monName = "March";
                        break;
                case 4: monName = "April";
                        break;
                case 5: monName = "May";
                        break;
                case 6: monName = "June";
                        break;
                case 7: monName = "July";
                        break;
                case 8: monName = "August";
                        break;
                case 9: monName = "September";
                        break;
                case 10: monName = "October";
                        break;
                case 11: monName = "November";
                        break;
                case 12: monName = "December";
                        break;
            default: cout << "This is not right some how.";
        }           
    
    //Accept User Input
    cout << "Please enter the day of the month: ";
    cin >> day;
    display.setDay(day);
    //Set 2nd Date variable to the original date of display
    displayS = display;
    cout << endl;
    
    //Input Validation
    if (mth == 1 || mth == 3 || mth == 5 || mth == 7 || mth == 8 ||
            mth == 10 || mth == 12)
    {
        do{
            if(day < 1 || day > 31)
            {
                cout << "Please enter another day: ";
                cin >> day;
            }
        }while(day < 1 || day > 31);
    }
    
    if (mth == 4 || mth == 6 || mth == 9 || mth == 11)
    {
        do{
            if (day > 30 || day < 1)
            {
                cout << "Please enter another day: ";
                cin >> day;
            }               
        }while(day > 30 || day < 1);
    }
    
    if (mth == 2)
    {
        do{
            if (day > 28 || day < 1)
            {
                cout << "Please enter another day: ";
                cin >> day;
            }               
        }while(day > 28 || day < 1);
    }
   
   //Accept User Input 
   cout << "Please enter the year: ";
   cin >> year;
   cout << endl;
   
   //Display output
   cout << "This is the first display." << endl;
   display.DisOne(mth, day, year);
   cout << "\nThis is the second display." << endl;
   display.DisTwo(monName, day, year);
   cout << "\nThis is the third display." << endl;
   display.DisThree(monName, day, year);
   
   ++display;
   day = display.getDay();
   display.setDay(day);
   
   cout << "\n\nNow the date will be incremented by one.";
   
   //Display output
   cout << "\n\nThis is the first display." << endl;
   display.DisOne(mth, day, year);
   cout << "\nThis is the second display." << endl;
   display.DisTwo(monName, day, year);
   cout << "\nThis is the third display." << endl;
   display.DisThree(monName, day, year);
   
   //Subtract the previous day with the original
    display-displayS;
    day = display.getDay();
    
    cout << "\nThis is the output with the days of the previous and the original "
            "subtracted together: ";
    
    //Display output
   cout << "\n\nThis is the first display." << endl;
   display.DisOne(mth, day, year);
   cout << "\nThis is the second display." << endl;
   display.DisTwo(monName, day, year);
   cout << "\nThis is the third display." << endl;
   display.DisThree(monName, day, year);
    
    cout << endl;
   
   display++;
   day = display.getDay();
   display.setDay(day);
   
   cout << "\n\nNow the date will be incremented by one.";
   
   //Display output
   cout << "\n\nThis is the first display." << endl;
   display.DisOne(mth, day, year);
   cout << "\nThis is the second display." << endl;
   display.DisTwo(monName, day, year);
   cout << "\nThis is the third display." << endl;
   display.DisThree(monName, day, year);
   
   display--;
   day = display.getDay();
   display.setDay(day);
   
   cout << "\n\nNow the date will be incremented by one.";
   
   //Display output
   cout << "\n\nThis is the first display." << endl;
   display.DisOne(mth, day, year);
   cout << "\nThis is the second display." << endl;
   display.DisTwo(monName, day, year);
   cout << "\nThis is the third display." << endl;
   display.DisThree(monName, day, year);
   
   return 0;
}

void Date::DisOne(int mon, int day, int year)
{
    cout << mon << "/" << day << "/" << year << endl;
}

void Date::DisTwo(string mon, int day, int year)
{
    cout << mon << " " << day << ", " << year << endl;
}

void Date::DisThree(string mon, int day, int year)
{
    cout << day << " " << mon << " " << year << endl;
}