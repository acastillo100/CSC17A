//Alex Castillo                 CSC17A                 Chapter 15, P.964, #4
//
/***************************************************************************
* DISPLAY TIME
* __________________________________________________________________________
* This program creates a class called MilTime that is derived from the Time class. 
* The MilTime class should convert time in military (24-hour) format to the 
* standard time format used by the Time class. The program then displays the time 
* in both military and standard format.
* 
* **************************************************************************
* INPUT
* hour                 : Hour of the time
* seconds              : Seconds of the time
* 
* 
* OUTPUT
* 
* time.getMilHour()        : Military time output
* time.getStandHr()        : Standard time output
* __________________________________________________________________________
****************************************************************************/


#include "Time.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    int hour, seconds;
    MilTime time;
    
    cout << "Enter the hour (in military time): ";
    cin >> hour;
    cout << "\nEnter the current seconds: ";
    cin >> seconds;
    
    time.setTime(hour, seconds);
    
    time.getMilHour();
    
    time.getStandHr();
    return 0;
}