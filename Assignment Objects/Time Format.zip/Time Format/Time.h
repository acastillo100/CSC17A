/* 
 * File:   Time.h
 * Author: Alex
 *
 * Created on November 17, 2017, 12:00 PM
 */

#ifndef TIME_H
#define TIME_H

#include <iostream>
#include <iomanip>

using namespace std;

class Time
 {
protected:
     int hour;
     int min;
     int sec;
public:
     // Default constructor
     Time()
    {
        hour = 0;
        min = 0;
        sec = 0;
    }

     // Constructor
     Time(int h, int m, int s)
    {
        hour = h;
        min = m;
        sec = s;
    }

     // Accessor functions
     int getHour() const
    {
        if (hour >= 0 && hour < 24)
            return hour;
    }
   
    int getMin() const
    {
        if (min >= 0 && min < 60)
        return min;
    }

    
    int getSec() const
    {
        if (sec >= 0 && sec < 60)
        return sec;
    }
};


class MilTime:public Time
{
private:
    int milHour;
    int milSecs;
    
public:
    // Default constructor
     MilTime()
    {
        milHour = 0;
        milSecs = 0;
    }

     // Constructor
     MilTime(int milH, int milS)
    {
        milHour = milH;
        milSecs = milS;
    }
     
     void setTime(int milH, int milS)
     {
         if (milH > 1259 && milH < 2400)
             hour = (milH - 1200);
         if (hour % 100 == 0)
             hour = hour / 100;
         else
             hour = milH;
         sec = milS;
         milHour = milH;
         milSecs = milS;        
     }
     
     void getMilHour()
     {
         if (milHour >= 0 && milHour < 2400 && milSecs >= 0 && milSecs < 60)
             cout << "\nThis is the time in military time: " << milHour 
                     << " hours. "  milSecs << " seconds";   
     }
     
     void getStandHr()
     {
         cout << "\nThis is the time in standard time: " << hour << ":" << min 
                 << ":" << sec;
     }  
};
#endif /* TIME_H */