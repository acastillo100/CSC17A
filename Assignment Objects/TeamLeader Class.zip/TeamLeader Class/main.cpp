//Alex Castillo                 CSC17A                 Chapter 15, P.964, #3
//
/***************************************************************************
* DISPLAY TEAM LEADER INFO
* __________________________________________________________________________
* This program creates a class named Employee. The class should keep the following 
* information of an employee name, employee number, and hire date.  It creates 
* constructors and the appropriate accessor and mutator functions for the class. 
* Then it writes a class named the TeamLeader class and has a member variable 
* that holds the annual salary and a member variable that holds the annual 
* production bonus that a shift supervisor has earned.
* 
* **************************************************************************
* INPUT
* name                          : Name of new employee
* info                          : Info of new employee (Employee #, date, shift)
* pay                           : Hourly rate
* anSal                         : Annual Salary for ShiftSupervisor
* aPBonus                       : Annual Production Bonus for ShiftSupervisor
* 
* 
* OUTPUT
* 
* super.get_           : Displays the info of the Supervisor
* __________________________________________________________________________
****************************************************************************/

#include "Employee.h"
#include <string>
#include <iostream>
using namespace std;

int main(int argc, char** argv) 
{
    ProductionWorker sorter("Alex", 9102, 19051998, 1, 12.5);
    cout << sorter.getName() << " is the worker with the title of sorter." 
         << "\nHis employee # is: " << sorter.getNum()
         << "\nHe was hired on (D/M/Y): " << sorter.getDate()
         << "\nHe works the " << sorter.getShft() << " shift."
         << "\n,He gets paid $" << sorter.getPayRt() << " per hour.";
    
    ProductionWorker worker;
    TeamLeader leader;
    string name;
    int info;
    float pay;
    int hours;
    
    
    cout << "\n\nPlease input the new worker's information:" << endl;
    cout << "What is his name: ";
    cin >> name;
    worker.setName(name);
    cout << "\nWhat is his employee number (####): ";
    cin >> info;
    worker.setNum(info);
    cout << "\nWhen was he hired (D/M/Y): ";
    cin >> info;
    worker.setDate(info);
    cout << "\nWhich shift does he work? (1=Day, 2=Night): ";
    cin >> info;
    worker.setShft(info);
    cout << "\nWhat is his hourly wage: $";
    cin >> pay;
    worker.setPayRt(pay);
    //Display info
    cout << endl << worker.getName() << " is the new worker."
         << "\nHis employee # is: " << worker.getNum()
         << "\nHe was hired on (YYYYMMDD): " << worker.getDate()
         << "\nHe works the " << worker.getShft() << " shift."
         << "\nHe gets paid $" << worker.getPayRt() << " per hour.\n\n";
    
    //Info for ShiftSupervisor
    cout << "\n\nPlease input the Team Leader's information:" << endl;
    cout << "What is their name: ";
    cin >> name;
    leader.setName(name);
    cout << "\nWhat is his employee number (####): ";
    cin >> info;
    leader.setNum(info);
    cout << "\nWhen was he hired (D/M/Y): ";
    cin >> info;
    leader.setDate(info);
    
    
    cout << "\nHow many training hours have they attended this month?: ";
    cin >> hours;
    leader.setTrainHours(hours);
    if (hours > leader.getHoursNeeded())
       pay = leader.getMonthBonus(); 
    else
    {
        pay = 0;
        leader.setMonthBonus(pay);
    }

    //Display info
    cout << endl << leader.getName() << " is the supervisor."
         << "\nTheir employee # is: " << leader.getNum()
         << "\nThey was hired on (YYYYMMDD): " << leader.getDate()
         << "\nTheir monthly bonus is $" << pay << "."
         << "\nTheir training hours attended is " << leader.getTrainHours() << 
            ".\n\n";  
    return 0;
}