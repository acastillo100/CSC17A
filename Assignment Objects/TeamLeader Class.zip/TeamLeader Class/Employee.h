/* 
 * File:   Employee.h
 * Author: Alex
 *
 * Created on November 16, 2017, 3:20 PM
 */

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "string"
using namespace std;

class Employee
{
    protected:                  //Inheritance
    //Protected variables
    string name;                //Name for employee
    int num;                    //Number for employee
    int date;                   //Hire date of employee (YYYY/MM/DD)
    
    public:
        
    //Constructors
    Employee();

    Employee(string names, int number, int day);
    
    //Mutators (public)
    void setName(string value);
    void setNum(int value);
    void setDate(int value);
    
    //Accessors (public)
    string getName() const;
    int getNum() const;
    int getDate() const;
};

class ProductionWorker : public Employee
{
    protected:
    //Variables
    int shift; //Hourly Shift
    float payRt; //Pay Rate
    
    public:
    //Constructors
    ProductionWorker();
    ProductionWorker(string names, int number, int day, int sft, float prt);
    
    //Mutators (public)
    void setShft(int value);
    void setPayRt(float value);
    
    //Accessors (public)
    string getShft() const;
    float getPayRt() const;
};

class TeamLeader : public ProductionWorker
{
private:
    //Variables
    float mBonus;      //Monthly Bonus
    int tNeeded;       //Training hours needed
    int tHours;        //Training hours
    
public:
    //Constructors
    TeamLeader();
    TeamLeader(string names, int number, int day, int sft, float prt, float monthB, 
               int trainN, int trainH);
    
    //Mutators
    void setMonthBonus(float monthB);
    void setTrainHours(int trainH);
    
    //Accessors
    float getMonthBonus() const;
    int getHoursNeeded() const;
    int getTrainHours() const;
};

#endif /* EMPLOYEE_H */