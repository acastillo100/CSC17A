#include "Employee.h"
using namespace std;

//Constructors of Employee class
Employee::Employee()
{
    name = "Null";
    num = 0;
    date = 0.0;
}

Employee::Employee(string names, int number, int day)
{
    name = names;
    num = number;
    date = day;
}

//Set mutators
void Employee::setName(string names)
{
    name = names;
}
void Employee::setNum(int number)
{
    num = number;
}
void Employee::setDate(int day)
{
    date = day;
}


//The accessors
string Employee::getName() const
{
    return name;
}
int Employee::getNum() const
{
    return num;
}
int Employee::getDate() const
{
    return date;
}

//Set constructor of the ProductionWorker Class
ProductionWorker::ProductionWorker():Employee()
{
    shift = 0;
    payRt = 0.0;
}
ProductionWorker::ProductionWorker(string nam, int num, int dat, int sft, float 
                                   prt):Employee(nam, num, dat)
{
    shift = sft;
    payRt = prt;
}

//Mutators of ProductionWorker Class
void ProductionWorker::setShft(int value)
{
    shift = value;
}
void ProductionWorker::setPayRt(float value)
{
    payRt = value;
}

//Accessors of ProductionWorker Class
string ProductionWorker::getShft() const
{
    if (shift == 1) 
        return "Day";
    else if (shift == 2) 
        return "Night";
    else 
        return "Error";
}
float ProductionWorker::getPayRt() const
{
    return payRt;
}

//Set constructor of the TeamLeader Class
TeamLeader::TeamLeader():ProductionWorker()
{
    mBonus = 300.0;  
    tNeeded = 60; 
    tHours = 0;  
}

TeamLeader::TeamLeader(string names, int number, int day, int sft, float prt, 
        float monthB, int trainN, int trainH):ProductionWorker()
{
    mBonus = monthB;
    tNeeded = trainN;
    tHours = trainH;
}

//Mutators of ProductionWorker Class
void TeamLeader::setMonthBonus(float monthB)
{
    mBonus = monthB;
}

void TeamLeader::setTrainHours(int trainH)
{
    tHours = trainH;
}

//Accessors of ProductionWorker Class
float TeamLeader::getMonthBonus() const
{
    return mBonus;
}

int TeamLeader::getHoursNeeded() const
{
    return tNeeded;
}

int TeamLeader::getTrainHours() const
{
    return tHours;
}       