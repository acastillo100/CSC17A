/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Employee.h
 * Author: Alex
 *
 * Created on November 16, 2017, 12:19 PM
 */

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "string"
using namespace std;

class Employee
{
    protected:                  //Inheritance
    //Protected variables
    string name;                //Name for employee
    int num;                    //Number for employee
    int date;                   //Hire date of employee (YYYY/MM/DD)
    
    public:
        
    //Constructors
    Employee();

    Employee(string names, int number, int day);
    
    //Mutators (public)
    void setName(string value);
    void setNum(int value);
    void setDate(int value);
    
    //Accessors (public)
    string getName() const;
    int getNum() const;
    int getDate() const;
};

class ProductionWorker : public Employee
{
    private:
    //Variables
    int shift; //Hourly Shift
    float payRt; //Pay Rate
    
    public:
    //Constructors
    ProductionWorker();
    ProductionWorker(string names, int number, int day, int sft, float prt);
    
    //Mutators (public)
    void setShft(int value);
    void setPayRt(float value);
    
    //Accessors (public)
    string getShft() const;
    float getPayRt() const;
};

#endif /* EMPLOYEE_H */