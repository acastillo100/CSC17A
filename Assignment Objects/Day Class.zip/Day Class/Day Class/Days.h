/* 
 * File:   Days.h
 * Author: Alex
 *
 * Created on November 13, 2017, 5:40 PM
 */

#ifndef DAYS_H
#define DAYS_H

#include <string>

class DayOfYear
{
private:
    int day;
    
public: 
    DayOfYear()
    {
        day = 0;
    }
    
    DayOfYear(int numDay)
    {
        numDay = day;
    }
    
    void setNumber(int numDay){(numDay >= 0); day = numDay;}   
    int getNumber() {return day;}
    void print(int numDay);
};

#endif /* DAYS_H */