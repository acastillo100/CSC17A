/* 
 * File:   ClassDate.h
 * Author: Alex
 *
 * Created on October 16, 2017, 8:10 AM
 */

#ifndef CLASSDATE_H
#define CLASSDATE_H
#include <string>

class Date
{
private:
    int month, day, year;
    std::string exMonth;
    
public: 
    void DisOne(int, int, int);
    void DisTwo(std::string month, int, int);
    void DisThree(std::string month, int, int);   
};



#endif /* CLASSDATE_H */

