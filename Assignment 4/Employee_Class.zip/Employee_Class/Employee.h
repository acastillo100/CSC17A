/* 
 * File:   Employee.h
 * Author: Alex
 *
 * Created on October 17, 2017, 1:00 PM
 */

#ifndef RETAILITEMS_H
#define RETAILITEMS_H

#include <string>

class Employee
{
private:
    // Member variables created and names being altered so they do not
    // conflict with the mutator and acessor functions.
    std::string name;
    int         idNumber;
    std::string department;
    std::string position;

public:
    Employee( std::string person   = "Blank",
            int         empId  = 0,
            std::string depart = "Blank",
            std::string posit  = "Blank")
 
    {
        name        = person;
        idNumber    = empId;
        position    = posit;
        department  = depart;
    }


    std::string names(std::string person) {return name = person;}
    std::string names()               {return name;}

    int idNum(int empId) {return idNumber = empId;}
    int idNum()       {return idNumber;}
    
    std::string dep(std::string area) {return department = area;}
    std::string dep()               {return department;}

    std::string place(std::string posit) {return position = posit;}
    std::string place()          {return position;}

};

#endif /* RETAILITEMS_H */

