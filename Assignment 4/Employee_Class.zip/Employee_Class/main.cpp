//Alex Castillo                 CSC17A                 Chapter 13, P.802, #2
//
/***************************************************************************
* DISPLAY EMPLOYEE CLASS
* __________________________________________________________________________
* This program creates a class named Employee that has the following member 
* variables: name, idNumber, department, and position. The class also has
* a constructor that accepts the following values as arguments and assigns 
* them to the appropriate member variables: employee’s name, employee’s ID 
* number, department, and position. A constructor that accepts the following 
* values as arguments and assigns them to the appropriate member variables: 
* employee’s name and ID number. The department and position fields should be 
* assigned an empty string ( "" ). Also a default constructor that assigns 
* empty strings ( "" ) to the name , department , and position member 
* variables, and 0 to the idNumber member variable.
* 
* **************************************************************************
* INPUT
* 
* Employee (person1/2/3)  : User defined variable to hold item info
* 
* OUTPUT
* 
* person1/2/3.names()    : Output the name of the person.
* person1/2/3.idNum()    : Output the IdNumber of the person.
* person1/2/3.dep()      : Output the department of the person.
* person1/2/3.place()    : Output the position of the person.
* __________________________________________________________________________
****************************************************************************/
#include "Employee.h"
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) 
{
    // Initialize variables
    Employee person1 ("Susan Meyers", 47899, "Accounting", "Vice President");

    Employee person2 ("Mark Jones", 39119, "IT", "Programmer");

    Employee person3 = Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");


    cout << fixed << setprecision(2);

    // Output data 
    cout << left << setw(18) << "Name"
         << left << setw(14) << "ID Number"
         << left << setw(14) << "Department"
         << left << setw(18) << "Position"   
         << '\n';
    
    cout << "-----------------------------------------------------------"
         << "----------------------\n";
    
    cout << left << setw(18) << person1.names()
         << left << setw(14) << person1.idNum()
         << left << setw(14) << person1.dep()
         << left << setw(18) << person1.place() 
         << '\n';
    
    cout << left << setw(18) << person2.names()
         << left << setw(14) << person2.idNum()
         << left << setw(14) << person2.dep()
         << left << setw(18) << person2.place()
         << '\n';
    
    cout << left << setw(18) << person3.names() 
         << left << setw(14) << person3.idNum()   
         << left << setw(14) << person3.dep()
         << left << setw(18) << person3.place() 
         << '\n';

    return 0;
}