//Alex Castillo                 CSC17A                 Chapter 13, P.803, #5
//
/***************************************************************************
* DISPLAY RETAIL ITEM CLASS
* __________________________________________________________________________
* This program holds data about an item in a retail store. It creates a 
* constructor that accepts arguments for each member variable, appropriate
* mutator functions that store values in these member variables, and 
* accessor functions that return the values in these member variables. 
* 
* **************************************************************************
* INPUT
* 
* RetailItem	      : User defined variable to hold item info
* 
* OUTPUT
* 
* item1/2/3.des()     : Output the description of the item.
* item1/2/3.OnHand()  : Output the quantity of the item
* item1/2/3.prices()  : Output the price of the item.
* __________________________________________________________________________
****************************************************************************/
#include "RetailItems.h"
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) 
{
    // Initialize variables
    RetailItem item1 ("Jacket", 12, 59.95);

    RetailItem item2 ("Designer Jeans", 40, 34.95);

    RetailItem item3 = RetailItem("Shirt", 20, 24.95);


    cout << fixed << setprecision(2);

    // Output data 
    cout << left << setw(12) << " "
         << left << setw(22) << "Description"
         << left << setw(16) << "Units on Hand"
         << left << setw(9) << "Price"
         << '\n';
    cout << "-----------------------------------------------------------\n";
    cout << left << setw(12) << "Item #1"
         << left << setw(22) << item1.des()
         << left << setw(16) << item1.OnHand()
         << left << setw(9) << item1.prices()
         << '\n';
    cout << left << setw(12) << "Item #2"
         << left << setw(22) << item2.des()
         << left << setw(16) << item2.OnHand()
         << left << setw(9) << item2.prices()
         << '\n';
    cout << left << setw(12) << "Item #3"
         << left << setw(22) << item3.des() 
         << left << setw(16) << item3.OnHand()   
         << left << setw(9) << item3.prices()
         << '\n';


    return 0;
}