/* 
 * File:   RetailItems.h
 * Author: Alex
 *
 * Created on October 17, 2017, 11:42 AM
 */

#ifndef RETAILITEMS_H
#define RETAILITEMS_H

#include <string>

class RetailItem 
{
private:
    // Member variables created and names being altered so they do not
    // conflict with the mutator and acessor functions.
    std::string description;
    int         unitsOnHand;
    float       price;

public:
    RetailItem( std::string descrip = "Blank",
                int         units = 0,
                float      prices = 0.0 )
 
    {
        description = descrip;
        unitsOnHand = units;
        price      = prices;
    }


    std::string des()               {return description;}
    std::string des(std::string mess) {return description = mess;}

    int OnHand(int unit) {return unitsOnHand = unit;}
    int OnHand()       {return unitsOnHand;}

    float prices(float pric) {return price = pric;}
    float prices()          {return price;}

};

#endif /* RETAILITEMS_H */

