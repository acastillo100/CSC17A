/* 
 * File:   Invent.h
 * Author: Alex
 *
 * Created on October 17, 2017, 7:00 PM
 */

#ifndef INVENT_H
#define INVENT_H

class Inventory
{
private:
    int itemNumber;
    int quantity;        //     quantity of the items on-hand
    float cost;         //wholesale per-unit cost of the ii
    float totalCost;     // total inventory cost of the item (items * cost

public:
    Inventory()
    {
        itemNumber = quantity = 0;
        cost = totalCost = 0.0;
    }

    Inventory( int invtNum, float invCost, int ivntQty)
    {
        itemNumber = invtNum;
        quantity = ivntQty;
        cost = invCost;
        setTotalCost();
    }

    void setItemNumber(int invtNum){(invtNum >= 0); itemNumber = invtNum;}
    void setQuantity(int ivntQty) {(ivntQty >= 0); quantity = ivntQty;}
    void setCost(float invCost) {(invCost >= 0); cost = invCost;}
    void setTotalCost(){totalCost =  cost * quantity; }

    int getItemNumber() {return itemNumber;}
    int getQuantity() { return quantity;}
    float getCost() {return cost;}
    float getTotalCost() { return totalCost; }
};

bool isNegative(int input) { return (input < 0); }
bool isNegative(float input){ return (input < 0); }

#endif /* INVENT_H */

