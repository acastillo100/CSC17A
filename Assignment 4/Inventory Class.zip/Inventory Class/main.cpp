//Alex Castillo                 CSC17A                 Chapter 13, P.804, #6
//
/***************************************************************************
* DISPLAY INVENTORY CLASS
* __________________________________________________________________________
* This program holds data about an item in a retail store. It creates a 
* constructor that accepts arguments for each member variable, appropriate
* mutator functions that store values in these member variables, and 
* accessor functions that return the values in these member variables. 
* 
* **************************************************************************
* INPUT
* 
* amn	      : User submitted item price
* num         : User submitted item number
* qnty        : User submitted item quantity
* 
* OUTPUT
* 
* getItemNumber()     : Output the number of the item.
* getQuantity()       : Output the quantity of the item
* getCost()           : Output the price of the item.
* getTotalCost()      : Output the total cost
* __________________________________________________________________________
****************************************************************************/

#include <iostream>
#include <iomanip>
#include "Invent.h"
using namespace std;


int main(int argc, char** argv)
{
    Inventory invItem;
    char go = 'y';
    float amn;
    int num,qnty;

    do {
          do
          {
              cout << "Enter item number: ";
              cin >> num;
              if (isNegative(num)) cout << "No negative numbers allowed" << endl;
          }while (isNegative(num));
          
        invItem.setItemNumber(num);

          do 
          {
              cout << "Enter item quantity: ";
              cin >> qnty;
              if (isNegative(qnty)) cout << "No negative numbers allowed" << endl;
          }while (isNegative(qnty));
          
        invItem.setQuantity(qnty);

          do 
          {
              cout << "Enter item price: ";
              cin >> amn;
              if (isNegative(amn)) cout << "No negative numbers allowed" << endl;
          }while (isNegative(amn));
          
        invItem.setCost(amn);

        invItem.setTotalCost();
        cout << "===============================" << endl;
        cout << " Item Number:\t" << invItem.getItemNumber() << endl;
        cout << " Item Quantity:\t"  << invItem.getQuantity()<< endl;
        cout << " Item Price:\t" << fixed << setprecision(2) <<  invItem.getCost()<< endl;
        cout << " Total Cost:\t" << fixed << setprecision(2) << invItem.getTotalCost()<< endl;
        cout << "===============================" << endl;

        cout << "Would you like to run the program again? Y or N" << endl;
        cin.ignore();
        cin >> go;
    }
    while (go == 'y' || go == 'Y' );

    cout << "Done!\n";
    cin.get();

    return 0;
}