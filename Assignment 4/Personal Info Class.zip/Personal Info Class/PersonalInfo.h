/* 
 * File:   PersonalInfo.h
 * Author: Alex
 *
 * Created on October 16, 2017, 8:10 AM
 */

#ifndef CLASSDATE_H
#define CLASSDATE_H
#include <string>

class Info
{
private:
    int *age;
    float *pNumber;
    std::string *name; 
    std::string *address;
    
public: 
    void DisOne(std::string *nama, std::string *place, int*, float*, const int);  
};



#endif /* CLASSDATE_H */

