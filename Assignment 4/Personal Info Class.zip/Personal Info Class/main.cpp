//Alex Castillo                 CSC17A                 Chapter 13, P.803, #4
//
/***************************************************************************
* DISPLAY PERSONAL INFO
* __________________________________________________________________________
* This program creates a class that holds the following personal data: name, 
* address, age, and phone number. It creates three instances of it the data. 
* One instance should hold the user's, and the other two should hold 
* friends’ or family members’ information.
* 
* **************************************************************************
* INPUT
* 
* age	           : Age submitted by the user
* name		   : Name submitted by the user
* address          : Address submitted by the user
* phonNum          : Phone number inputed
* 
* OUTPUT
* 
* displayOne       : Output the input three times
* 
* __________________________________________________________________________
****************************************************************************/
#include <iostream>
#include <string>
#include "PersonalInfo.h"

using namespace std;

int main()
{
    //Initialize variables
    Info display;
    const int NUM = 3;
    int age[NUM];
    float phonNum[NUM];
    string name[NUM], address[NUM];
    
    
    //Accept User Input
    for (int index = 0; index < NUM; index++)
    {
        cout << "Please enter the name for person #" << index+1 << ": ";
        getline(cin,name[index]);
    }
    
    for (int index = 0; index < NUM; index++)
    {
        cout << "\nPlease enter the address for person #" << index+1 << ": ";
        getline(cin,address[index]);
        cin.ignore(1000, '\n');
    }
    
    for (int index = 0; index < NUM; index++)
    {
        cout << "\nPlease enter the age for person #" << index+1 << ": ";
        cin >> age[index];
    }
    
    for (int index = 0; index < NUM; index++)
    {
        cout << "\nPlease enter the phone number for person #" << index+1 << ": ";
        cin >> phonNum[index];
    }
   
   //Display output
   cout << "This is the display for all three people." << endl;
   display.DisOne(name, address, age, phonNum, NUM);
   
   return 0;
}

void Info::DisOne(string *nama, string *place, int *age, float *number, const int NUM)
{
    for (int index = 0; index < NUM; index++)
    {
        cout << nama[index] << " is " << age[index] << " years old and lives at " 
             << place[index] << ".\n Their phone number is " << number[index] << 
                ".\n"; 
    }
}

