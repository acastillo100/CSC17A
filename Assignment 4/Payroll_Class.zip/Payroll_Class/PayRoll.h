/* 
 * File:   Payroll.h
 * Author: Alex
 *
 * Created on October 18, 2017, 9:10 PM
 */

#ifndef PAYROLL_H
#define PAYROLL_H

class Payroll
{
private:
    int hoursWk;
    float payRte;
    float totPay; 
    float grossPy;
    
public: 
    Payroll()
    {
        hoursWk = 0;
        payRte = 0.0;
        totPay = 0.0;
        grossPy = 0;
    }
    
    Payroll( int workHr, float payRate, float totlPay)
    {
        hoursWk = workHr;
        payRte = payRate;
        totPay = totlPay;
        setGrossPay();
    }
    
    void setHoursWrk(int workHr){(workHr >= 0); hoursWk = workHr;}
    void setPayRate(float payRate) {(payRate >= 0); payRte = payRate;}
    void setTotalPay(float totlPay) {(totlPay >= 0); totPay = totlPay;}
    void setGrossPay(){grossPy =  (hoursWk * payRte); }
    
    int getHoursWrk() {return hoursWk;}
    float getPayRate() { return payRte;}
    float getTotalPay() {return totPay;}
    float getGrossPay() { return grossPy; }
    
    bool isOver(int input) { return (input > 60 || input < 0); }

};

#endif /* PAYROLL_H */

