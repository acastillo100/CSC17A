//Alex Castillo                CSC17A                 Chapter 13, P.806, #11
//
/***************************************************************************
* DISPLAY PAYROLL INFO
* __________________________________________________________________________
* This program creates a class that holds the following employee data: an 
* employee’s hourly pay rate, number of hours worked, and total pay for the 
* week. It creates an array of seven PayRoll objects. The program should ask
* the user for the number of hours each employee has worked and then display 
* the amount of gross pay each has earned.
* 
* **************************************************************************
* INPUT
* 
* hrsWrk	           : Hours worked submitted by the user
* hrPRate		   : Hourly pay rate submitted by the user
* totPay                   : Total pay submitted by the user
* 
* OUTPUT
* 
* displayOne       : Output the input three times
* 
* __________________________________________________________________________
****************************************************************************/
#include <iostream>
#include <iomanip>
#include "PayRoll.h"

using namespace std;

int main()
{
    //Initialize variables
    const int NUM = 7;
    Payroll info[NUM];
    int hrsWrk[NUM];
    float hrPRate[NUM],
          totPay[NUM],
          grosPay[NUM];
    
    
    //Accept User Input
    for (int index = 0; index < NUM; index++)
    {
        cout << "Please enter the hours worked for person #" << index+1 << ": ";
        cin >> hrsWrk[index];
        info[index].setHoursWrk(hrsWrk[index]);
        cout << endl;
        
    }

    for (int index = 0; index < NUM; index++)
    {
        cout << "\nPlease enter the hourly pay rate for person #" << index+1 << ": ";
        cin >> hrPRate[index];
        info[index].setPayRate(hrPRate[index]);
    }
    
    cout << endl;
    
    for (int index = 0; index < NUM; index++)
    {
        cout << "\nPlease enter the total pay for person #" << index+1 << ": ";
        cin >> totPay[index];
        info[index].setTotalPay(totPay[index]);
    }
    
    for (int index = 0; index < NUM; index++)
    {
        info[index].setGrossPay();
    }
   
    cout << endl;
    
    //Display output
    for (int index = 0; index < NUM; index++)
    {
        cout << "\n===============================" << endl;
        cout << "Employee #" << index+1 << endl;
        cout << "-------------------------------" << endl;
        cout << " Hours Worked:\t" << info[index].getHoursWrk() << endl;
        cout << " Pay Rate:\t" << fixed << setprecision(2) << info[index].getPayRate()<< endl;
        cout << " Total Pay:\t" << fixed << setprecision(2) <<  info[index].getTotalPay()<< endl;
        cout << " Gross Pay:\t" << fixed << setprecision(2) << info[index].getGrossPay()<< endl;
        cout << "===============================\n\n\n" << endl;
    }
   
   return 0;
}