//Alex Castillo                   CSC17A                  Chapter 11, P. 651, #3
//
/*******************************************************************************
 *
 * STORE AND COMPUTE SALES DATA
 * _____________________________________________________________________________
 * This program stores user input sales data of four different divisions. It is 
 * the stored in structure arrays so each corporate division name is 
 * initialized. It then calculates and displays the total annual sale and 
 * average quarterly sales. 
 *
 * Computation is based on the formula:
 * Total Annual Sales = 1st Quarter + 2nd Quarter + 3rd Quarter + 4th Quarter
 * Average Quarterly Sale = Total Annual / 4
 * _____________________________________________________________________________
 * INPUT
 *  divison   : Division name 
 *  qtr1Sal   : Quarter 1 sales
 *  qtr2Sal   : Quarter 2 sales
 *  qtr3Sal   : Quarter 3 sales
 *  qtr4Sal   : Quarter 4 sales
 *
 * OUTPUT
 *  totSale    : Total Annual Sale
 *  avgQtrSale : Average quarterly sale
 ******************************************************************************/
 
//System Libraries
#include <iostream>  
#include <iomanip>
 
using namespace std;  
 
struct SalesData
{
    string divison;
    float qtr1Sal;
    float qtr2Sal;
    float qtr3Sal;
    float qtr4Sal;
    float totSale;
    float avgQtrSal;
};
 
int main() 
{
    //Declaration of Variables
    SalesData divisions[4];
    const int area = 4;
 
    //Initialize
    divisions[0] = {"East Division"};
    divisions[1] = {"West Division"};
    divisions[2] = {"North Division"};
    divisions[3] = {"South Division"};
 
    //Input values
    for(int i = 0; i < area; i++)
    {
        cout <<" Please enter Data for the " << divisions[i].divison << endl;
        cout << "---------------------------------------------------------"<< endl;
        cout << "What are the first quarter sales  : $";
        cin >> divisions[i].qtr1Sal;
        cout << endl;
 
        //Validate
        if(divisions[i].qtr1Sal < 0)
        {
        	cout << "You can not enter negative values" <<endl;
        	cout << "What are the first quarter sales  : $";
        	cin >> divisions[i].qtr1Sal;
                cout << endl;
        }
 
        cout << "What are the second quarter sales  : $";
        cin >> divisions[i].qtr2Sal;
        cout << endl;
 
        
        if(divisions[i].qtr2Sal < 0)
        {
        	cout << "You can not enter negative values" << endl;
        	cout << "What are the second quarter sales  : $";
        	cin >> divisions[i].qtr2Sal;
                cout << endl;
        }
 
        cout << "What are the third quarter sales  : $";
        cin >> divisions[i].qtr3Sal;
        cout << endl;
 
        
        if(divisions[i].qtr3Sal < 0)
        {
        	cout << "You can not enter negative values" << endl;
        	cout << "What are the third quarter sales  : $";
        	cin >> divisions[i].qtr3Sal;
                cout << endl;
        }
 
        cout << "What are the fourth quarter sales  : $";
        cin >> divisions[i].qtr4Sal;
        cout << endl;
        
 
        if(divisions[i].qtr4Sal < 0)
        {
        	cout << "You can not enter negative values" << endl;
        	cout << "What are the fourth quarter sales  : $";
        	cin >> divisions[i].qtr4Sal;
                cout << endl;
        }
 
        cout<<"---------------------------------------------------------"<<endl;
 
        //Calculate Total and Average
        divisions[i].totSale = divisions[i].qtr1Sal + divisions[i].qtr2Sal + 
                               divisions[i].qtr3Sal + divisions[i].qtr4Sal;
 
        divisions[i].avgQtrSal = divisions[i].totSale / 4;
 
        //Display Total and Average
        cout << fixed << showpoint << setprecision(2);
        cout<<"Total Annual Sales\t: $" << divisions[i].totSale<<endl;
        cout<<"Average Quarterly Sales\t: $" << divisions[i].avgQtrSal<<endl;
        cout<<endl;
    }
 
    return 0;
}