//Alex Castillo                     CSC17A                Chapter 11, P. 652, #6
//
/*******************************************************************************
 *
 * Display Soccer Stats
 * _____________________________________________________________________________
 * This program will create a structure containing info about a soccer player
 * which includes the player’s name, the player’s number and points scored by 
 * the player. The program also asks the user to enter the data for each player. 
 * It then shows a table that lists each player’s number, name, and points 
 * scored. The program also calculates and displays the total points earned by
 * the team as well as the number and name of the player who has earned the most 
 * points.
 * 
 *
 * Computation is based on the formula:
 * None
 * _____________________________________________________________________________
 *   INPUT
 *   struct playInfo    : Contains name, number and points for each player
 * 
 * 
 *   OUTPUT
 *   Table of each player		
 *   totPoints                : Total Points of all player together
 * 
 ******************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

// Structure data type
struct playInfo
{
string playName;		// Input - Name of the soccer player 
int playNum;		        // Input - Number of the soccer player
int playScore;		        // Input - Number of points scored for the player
};

int main(int argc, char** argv)
{
    
    const int numPlayers = 12;
    playInfo soccer[numPlayers];
    int totGoals = 0;
    
    for (int index = 0; index < numPlayers; index++)
    {
        cout << "Please enter the name of player " << index+1 << ": ";
        getline(cin,soccer[index].playName);
        
        cout << "\nPlease enter the number of player " << index+1 << ":";
        cin >> soccer[index].playNum;
        cout << endl << endl;
        
        if (soccer[index].playNum < 0)
        {
            cout << "\nPlease enter a number 0 or higher:";
                    cin >> soccer[index].playNum;
                    cout << endl;
        }
        
        cout << "\nPlease enter the total goals of player " << index+1 << ":";
        cin >> soccer[index].playScore;
        cout << endl << endl;
        
        if (soccer[index].playScore < 0)
        {
            cout << "\nPlease enter a number 0 or higher:";
                    cin >> soccer[index].playScore;  
                    cout << endl;
        }
       
        cin.ignore();
        
    }
    
    for (int index = 0; index < numPlayers; index++)
    {
        totGoals += soccer[index].playScore;
        
    }
    
    cout << "Name" << setw(10) << "Number" << setw(10) << "Goals\n";
    cout << "____" << setw(10) << "______" << setw(10) << "_____\n";
    
    for (int index = 0; index < numPlayers; index++)
    {
        cout << soccer[index].playName << setw(5) << soccer[index].playNum;
        cout << setw(8) << soccer[index].playScore << endl;
    }
    
    cout << "\nThis is the total goals scored by all the players: " << totGoals;
    cout << endl;
    
    int max = soccer[0].playScore;
    int maxIndex = 0;
    for (int index = 0; index < numPlayers; index++)
    {
	if (soccer[index].playScore > max)
      {
	  max = soccer[index].playScore;
          maxIndex = index;
      }
    }
 
    cout << "The player with the most goals is: " << soccer[maxIndex].playName 
            << " with the number: " << soccer[maxIndex].playNum << endl;
            

    return 0;
}

