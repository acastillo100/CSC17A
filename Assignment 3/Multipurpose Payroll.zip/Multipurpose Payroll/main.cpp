//Alex Castillo			 CSC17A               Chapter 11,P.655,#15
/*************************************************************************
 *
 * Display Multipurpose Payroll
 * _____________________________________________________________________
 * This program asks user to choose either hourly worker or salary worker.
 * Hourly paid workers are paid their hourly pay rate times the number of hours
 * worked. Salaried workers are paid their regular salary plus any bonus 
 * they may have earned.
 * 
 * CALCULATIONS:
 * total hours worked * hourly pay = pay stub
 * total salary + bonus = pay stub
 * _______________________________________________________________________
 *INPUT
 *	hrWrk                           : Total hour worked
 *	hrRate			        : Per hour pay
 *	salary				: Total salary
 *	bonus				: Bonus of salary worker
 *
 *OUTPUT
 *	totalPay			: Hourly worker total pay
 *	totalPaySal			: Total salary + bonus
 *
 ************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;
 
//Structures to initialize variables for hours paid and salary info
struct HrlyPay
{
	int hrsWork;	     //Total hours worked
	float hrRate;	     //Hourly rate of worker
	float totalPay;	     //Calculated hourly pay
};
 
struct SalryPay
{
	float salary;	     //Salary per year
	float bonus;	     //Applied bonus
	float totPaySal;     //Calculated salary pay
};
 
//Function Prototype
HrlyPay calcHrsPaid(HrlyPay);
SalryPay calcSalaryPaid(SalryPay);
 
int main(int argc, char** argv)
{
    union payment
         {
           HrlyPay hourPay;
	   SalryPay salPay;
         };

        payment unHPay;
	payment unSPay;
 
	int choice;
 
	cout << "Please choose between worker hourly or salary?" << endl;
	cout << "1. Hourly Worker " << endl;
	cout << "2. Salary Worker " << endl;
	cin >> choice;
 
	switch (choice)
	{
	case 1: unHPay.hourPay = calcHrsPaid(unHPay.hourPay);
			break;
	case 2: unSPay.salPay = calcSalaryPaid(unSPay.salPay);
			break;
	default: cout << "Please enter number 1 or 2." << endl;
	}
 
	//Output the information
	cout << setprecision(2) << fixed << showpoint << endl;
	if (choice == 1)
	{
		cout << "Total Pay: " << endl;
		cout << "$" << unHPay.hourPay.totalPay;
	}
	else
	{
		cout << "Total Salary Paid: " << endl;
		cout << "$" << unSPay.salPay.totPaySal << endl;
	}
 
	return 0;
}

 // Get hourly worker info. Return calculated pay stub
HrlyPay calcHrsPaid(HrlyPay payStub)
{
	HrlyPay tempTotal;
 
	cout << "Enter hours worked: " << endl;
	cin >> payStub.hrsWork;
 
	cout << "Enter hourly pay: " << endl;
	cin >> payStub.hrRate;
 
	tempTotal.totalPay = payStub.hrsWork * payStub.hrRate;
 
	return tempTotal;
}
 

 
 //Get salary worker info. return calculated pay stub 
SalryPay calcSalaryPaid(SalryPay paySal)
{
	cout << "Enter Salary: " << endl;
	cin >> paySal.salary;
	cout << "Enter Bonus: " << endl;
	cin >> paySal.bonus;
 
	paySal.totPaySal = paySal.salary + paySal.bonus;
 
	return paySal;
}


