//Alex Castillo			 CSC17A               Chapter 11,P.653,#11
/*************************************************************************
 *
 * Display Spending
 * _____________________________________________________________________
 * This program creates a MonthlyBudget structure designed to hold
 * different categories. The program then passes the structure to a 
 * function that asks the user to enter the amounts spent in each budget 
 * category during a month. The program passes the structure to a function 
 * that displays a report indicating the amount over or under in each 
 * category, as well as the amount over or under for the entire monthly 
 * budget.
 * 
 * CALCULATIONS:
 * total = B.Housing + B.Util + B.housExp + B.Transport
           + B.Food + B. Medical + B.Insurance + B.Etainment +
	   B.Clothing + B.Other
 * _______________________________________________________________________
 *INPUT
 * 
 * MonthlyBudget : Structure holding the monthly budget set by the student  
 *
 *OUTPUT
 * Output table for if over or under for each category
 *
 ************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;
 
struct MBudget
{
	float  Housing,
	       Util,
	       housExp,
	       Transport,
	       Food,
	       Medical,
	       Insurance,
	       Etainment,
	       Clothing,
	       Other;
};
 
// Function Prototypes
void getSpent(MBudget &);
void displayReport(MBudget A, MBudget B);
void displayReportHelper(float B, float S);
float total(MBudget);
 

int main(int argc, char** argv)
{
	MBudget Budget = {500.00, 150.00, 65.00, 50.00, 250.00,
		                    30.00, 100.00, 150.00, 75.00, 50.00};
	MBudget Spent;
 
	getSpent(Spent);
 
	displayReport(Budget, Spent);
 
	return 0;
}
 

  //This function has the user enter the amounts actually spent in each budget   
  //category during the past month.                                             
void getSpent(MBudget &B)
{
	cout << "During the past month:\n";
	cout << "How much was spent on Housing? ";
	cin  >> B.Housing;
	cout << "How much was spent on Utilities? ";
	cin  >> B.Util;
	cout << "How much was spent on Household expenses? ";
	cin  >> B.housExp;
	cout << "How much was spent on Transportation? ";
	cin  >> B.Transport;
	cout << "How much was spent on Food? ";
	cin  >> B.Food;
	cout << "How much was spent on Medical? ";
	cin  >> B.Medical;
	cout << "How much was spent on Insurance? ";
	cin  >> B.Insurance;
	cout << "How much was spent on Entertainment? ";
	cin  >> B.Etainment;
	cout << "How much was spent on Clothing? ";
	cin  >> B.Clothing;
	cout << "How much was spent on Miscellaneous? ";
	cin  >> B.Other;
}
 
                             
  //This function accepts both MonthlyBudget variables as arguments. Then it d
  //displays a report indicating the amount over or under budget the student
  //spent in each category and the amount over or under the entire budget.                                                       

void displayReport(MBudget B, MBudget S)
{
	float totBuget, totSpnt;
 
	cout << "\n         Monthly budget report\n";
	cout << "------------------------------------------\n";
 
	cout << "Housing:            $";
	displayReportHelper(B.Housing, S.Housing);
 
	cout << "Utilities:          $";
	displayReportHelper(B.Util, S.Util);
 
	cout << "Household expenses: $";
	displayReportHelper(B.housExp, S.housExp);
 
	cout << "Transportation:     $";
	displayReportHelper(B.Transport, S.Transport);
 
	cout << "Food:               $";
	displayReportHelper(B.Food, S.Food);
 
	cout << "Medical:            $";
	displayReportHelper(B.Medical, S.Medical);
 
	cout << "Insurance:          $";
	displayReportHelper(B.Insurance, S.Insurance);
 
	cout << "Entertainment:      $";
	displayReportHelper(B.Etainment, S.Etainment);
 
	cout << "Clothing:           $";
	displayReportHelper(B.Clothing, S.Clothing);
 
	cout << "Miscellaneous:      $";
	displayReportHelper(B.Other, S.Other);
 
	totBuget = total(B);
 
	totSpnt = total(S);
 
	cout << "Entire budget:      $";
	displayReportHelper(totBuget, totSpnt);
}
 

 // This function accepts two MonthlyBudget member variables as arguments and
 // displays the amount over or under budget the student spent.
void displayReportHelper(float B, float S)
{
	cout << fixed << showpoint << setprecision(2);
	if (B > S)
	{
		cout << setw(7) << B - S;
		cout << " under.\n";
	}
	else
	{
		cout << setw(7) << S - B;
		cout << " over.\n";
	}
}
 

 // This function accepts the MonthlyBudget structure variable as an              
 // argument and returns the sum of it member values.  
float total(MBudget B)
{
	return B.Housing + B.Util + B.housExp + B.Transport
		   + B.Food + B. Medical + B.Insurance + B.Etainment +
		   B.Clothing + B.Other;
}