//Alex Castillo		         CSC17A		      Chapter 11, P.651, #2
//
/**************************************************************************
 * 
 * Display Movie Profit
 * _____________________________________________________________
 * 
 *  This program uses a structure named MovieData to store the 
 * title, director, year released, running time (in minutes),
 * the production costs and first year revenues of two different 
 * movies. The movie variables get passed into a function that 
 * displays the information about the movie.
 * _____________________________________________________________
 * INPUT
 *  movieOne
 *  movieTwo
 * 
 * OUTPUT
 *  displayInfo(movieOne)
 *  displayInfo(movieTwo)
 *************************************************************************/
 
 #include <iostream>
 #include <iomanip>
 #include <string>
 using namespace std;
 
 struct MovieData    // Structure to hold the variables for a movie
    {
    string movTitle;
    string director;
    int yrRelse;
    int runTime;
    float movCosts;
    float yrOneRev;
    };
    
 void displayInfo (MovieData movie);  
 
int main ()
{
    MovieData movieOne, movieTwo;
    
    // Get First Movie Information
	cout << "Enter the title for the first movie: ";
	getline(cin, movieOne.movTitle);
	cout << endl;
 
	cout << "Enter the name of the director for the first movie: ";
	getline(cin, movieOne.director);
	cout << endl;
 
	cout << "Enter release year for the first movie: ";
	cin >> movieOne.yrRelse;
	cout << endl;
 
	cout << "Enter run time of the first movie in minutes: ";
	cin >> movieOne.runTime;
	cout << endl;
        
        cout << "Enter the production costs for the first movie: ";
        cin >> movieOne.movCosts;
        cout << endl;
        
        cout << "Enter how much the first movie made in it's first year run: ";
        cin >> movieOne.yrOneRev;
        cout << endl << endl;
 
	// Get Second Movie Information
	cout << "Enter the title for the second movie: ";
	cin.ignore(100,'\n');
	getline(cin, movieTwo.movTitle);
	cout << endl;
 
	cout << "Enter the name of the director for the second movie: ";
	getline(cin, movieTwo.director);
	cout << endl;
 
	cout << "Enter release year for the second movie: ";
	cin >> movieTwo.yrRelse;
	cout << endl;
 
	cout << "Enter run time of the second movie in minutes: ";
	cin >> movieTwo.runTime;
	cout << endl;
        
        cout << "Enter the production costs for the second movie: ";
        cin >> movieTwo.movCosts;
        cout << endl;
        
        cout << "Enter how much the second movie made in it's first year run: ";
        cin >> movieTwo.yrOneRev;
        cout << endl << endl;
 
// Output
	displayInfo(movieOne);
	displayInfo(movieTwo);
    
 
    return 0;
}
 
// Display Movie Info Function
void displayInfo (MovieData movie)
{
    float movEarns = (movie.yrOneRev - movie.movCosts);
    
	cout << "MOVIE INFORMATION" << endl;
	cout << "___________________________________" << endl; 
	cout << "Title: " << movie.movTitle << endl;
	cout << "Director(s): " << movie.director << endl;
	cout << "Year Released: " << movie.yrRelse << endl;
	cout << "Run Time: " << movie.runTime << " minutes" << endl;
        cout << "Year one profit: $" << movEarns << endl << endl << endl;
}