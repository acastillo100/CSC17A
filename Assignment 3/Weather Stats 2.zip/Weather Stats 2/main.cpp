//Alex Castillo                     CSC17A                Chapter 11, P. 652, #5
//
/*******************************************************************************
 *
 * Compute weather statistics 
 * _____________________________________________________________________________
 * This program will require the user to enter information about total rain,
 * highest temp and lowest temp for each month of the year. It creates an
 * enumerated data type with enumerators for the months. Finally the 
 * program will compute and display total rainfall for the year, month with 
 * high temp and lowest temp. 
 * 
 *
 * Computation is based on the formula:
 * None
 * _____________________________________________________________________________
 *   INPUT
 *   total rain 	: total rain for the month 
 *   highest temp 	: highest temperature for the month 
 *   lowest temp  	: lowest temperature for the month 
 * 
 * 
 *   OUTPUT
 *   output		: display weather statistic information
 * 
 ******************************************************************************/
#include <iostream>
#include <string>
using namespace std;
 
// Structure data type
struct weathInfo
{
int totalRain;			// Input - total rainfall per month 
int highestTemp;		// Input - highest temperature per month 
int lowestTemp;		        // Input - lowest temperature per month 
int avgTemp;			// Output - Total average temperature
};
 
int main() 
{
	// Initialize variables
 
        enum Day { JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, 
        SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER};
	const int MONTHS = 12; 
	weathInfo weather[MONTHS];
	int highMonth;
	int lowMonth;
 	float highest = 0; 
	float lowest = 0; 
	float yearRain = 0.0; 
	float totalAvg = 0.0; 
 
 	// For loop 
	for (int counter = JANUARY; counter < DECEMBER; counter++)
	{
 
 
		// Input rainfall 
		cout << "Enter the amount of rain for month " << (counter + 1); 
		cout << ": "; 
		cin >> weather[counter].totalRain;
 
 
		// Calculate total rainfall 
		yearRain += weather[counter].totalRain; 
 
 
		// Input highest temperature 
		cout << "\nEnter the highest temperature for month " << (counter + 1); 
		cout << ": "; 
		cin >> weather[counter].highestTemp;
 
 
		// Input Validation 
while(weather[counter].highestTemp < -100 || weather[counter].highestTemp > 140)
		{
			cout << "Invalid input" << endl;
			cout << "Enter highest temperature for month " << (counter + 1) 
                        << ": " << endl;
			cin >> weather[counter].highestTemp;
		}
 
			// Highest temperature 
 			if (weather[counter].highestTemp > highest)
			{
				highMonth = (counter + 1);
				highest = weather[counter].highestTemp; 
			}
 
		// Input lowest temperature
		cout << "\nEnter lowest temperature for month " << (counter + 1) <<
				": ";
		cin >> weather[counter].lowestTemp;
		cout << endl;
 
		// Input validation 
while(weather[counter].lowestTemp < -100 || weather[counter].lowestTemp > 140)
		{
		cout << "Invalid input" << endl;
		cout << "What is the lowest temperature for month " << (counter + 1); 
		cout << ": ";
		cin >> weather[counter].lowestTemp;
		}
 
		if (weather[counter].lowestTemp > lowest)
		{
			lowMonth = (counter + 1);
			lowest = weather[counter].lowestTemp; 
 		}
 
		// Compute average temperature 
		weather[counter].avgTemp = 
		(weather[counter].highestTemp + weather[counter].lowestTemp) / 2;
 
		// Output 
		cout << "\nAverage temperature for month " << (counter + 1) << ": ";
		cout <<	weather[counter].avgTemp << endl;
		totalAvg += weather[counter].avgTemp;
		cout <<"Average monthly rainfall : "; 
		cout << (yearRain / (counter + 1 )) << endl;
		cout << endl;
	}
 
		// Output highest & lowest temperature,
 		cout << "Highest temperature: " << highest;
 		cout << " in month " << highMonth << endl; 
		cout << "Lowest temperature: " << lowest << " in month "; 
		cout << lowMonth << endl; 
 
		// Output total rainfall 
 		cout << "Total rainfall: " << yearRain << endl; 
 
 		// Output average rainfall 
 		cout << "Average yearly temperature: " << (totalAvg / 12.0); 
                
	return 0;
}