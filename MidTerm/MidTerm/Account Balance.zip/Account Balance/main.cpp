//Alex Castillo			 CSC17A               Chapter 11,P.653,#11
/*************************************************************************
 *
 * DISPLAY ACCOUNT BALANCE
 * _____________________________________________________________________
 * This program 
 * 
 * CALCULATIONS:
 * 
 * _______________________________________________________________________
 *INPUT
 * 
 *  : Structure holding the monthly budget set by the student  
 *
 *OUTPUT
 * 
 *
 ************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
 
struct Balance
{
    string name;
    string address;
    int accNum;
    float balance;
    float witdraw;
    float depos;
    float nBal;
};
 
// Function Prototypes
void findBal(Balance &);
void displayReport(Balance A);
void displayFeeHelper(float S);
 

int main(int argc, char** argv)
{

	Balance account {"None","None",0,0.0,0.0,0.0,0.0};
 
	findBal(account);
 
	displayReport(account);
 
	return 0;
}
 

  //This function has the user enter the amounts actually spent in each budget   
  //category during the past month.                                             
void findBal(Balance &A)
{
    int stopOne;
    int stopTwo;
    float lose[stopOne];
    
	cout << "Who is the holder of this account? ";
	getline(cin,A.name);
	cout << "\nWhat is the address tied to the account? ";
	getline (cin,A.address);
	
        do
        {
            cout << "\nWhat is the 5 digit account number? ";
            cin  >> A.accNum;
            if (A.accNum < 10000 || A.accNum > 99999)
            {
                cout << "\nPlease enter an acceptable account number. ";
                cin >> A.accNum;
            }
        }
        while (A.accNum < 10000 || A.accNum > 99999);
        
	cout << "\nHow much was the balance at the beginning of the month? ";
	cin  >> A.balance;
        
        
	cout << "\nHow many checks were written this month? ";
	cin  >> stopOne;
        
        for (int index = 0; index < stopOne; index++)
        {
            cout << "\nHow much was written to check " << index+1 << "? ";
            cin >> lose[index];
            A.witdraw += lose[index];
        }
        
	cout << "\nHow many deposits were credited this month? ";
	cin  >> stopTwo;
        
        for (int index = 0; index < stopTwo; index++)
        {
            float gain[stopTwo];
            cout << "\nHow much was deposit " << index+1 << "? ";
            cin >> gain[index];
            A.depos += gain[index];
        } 
        
	cout << "\nThis is the total amount withdrawn: " << A.witdraw;
        cout << "\nThis is the total amount deposited: " << A.depos;

}
 
                             
  //This function accepts both MonthlyBudget variables as arguments. Then it d
  //displays a report indicating the amount over or under budget the student
  //spent in each category and the amount over or under the entire budget.                                                       

void displayReport(Balance A)
{
	float totBuget, totSpnt;
 
	cout << "\n         Account Summary\n";
	cout << "------------------------------------------\n";
 
	cout << "Name:                  ";
	cout << setw(7) << A.name;
 
	cout << "\nAddress:             ";
	cout << setw(7) << A.address;
 
	cout << "\nBeginning Balance:  $";
        cout << setw(7) << A.balance;
 
	cout << "\nTotal Withdrawals:  $";
	cout << setw(7) << A.witdraw;
 
	cout << "\nTotal Deposits:     $";
	cout << setw(7) << A.depos;
        cout << endl;
        
        A.nBal = ((A.balance - A.witdraw)+ A.depos);
 
	displayFeeHelper(A.nBal);
}
 

 // This function accepts two MonthlyBudget member variables as arguments and
 // displays the amount over or under budget the student spent.
void displayFeeHelper(float S)
{
	cout << fixed << showpoint << setprecision(2);
	if (S < 0)
	{
                cout << "\nThis is the new balance." << endl;
                cout << setw(7) << "$" << S;
		cout << "\nThe account is overdrawn, a $15 fee will be applied.\n";
                cout << "\nThe balance you must pay is $" << (-1*(S-15)); 
	}
	else
	{
		cout << "This is the new balance." << endl;
                cout << setw(7) << "$" << S;
		cout << "\n The account is not overdrawn.";
	}
}