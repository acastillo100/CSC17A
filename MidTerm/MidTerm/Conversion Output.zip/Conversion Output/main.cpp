/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Alex
 *
 * Created on October 29, 2017, 12:23 AM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    cout << "2.875 in base 10 is: 10.111 in base 2, 2.7 in base 8, and";
    cout << " 2.E in base 16.\n\n";
    cout << "0.1796875 in base 10 is: 10.111 in base 2, 0.134 in base 8, and";
    cout << " 0.2E in base 16.\n\n";
    cout << "-2.875 in base 10 is: 1.001 in base 2, 1.000406111 in base 8, and";
    cout << " 1.00418937 in base 16.\n\n";
    cout << "-0.1796875 in base 10 is: 0.1101001 in base 2, 0.07027 in base 8, and";
    cout << " 0.1C2F8516 in base 16.\n\n";
    cout << "The float rep 59999901 in decimal form is 1503238401.\n";
    cout << "The float rep 59999902 in decimal form is 1503238402.\n";    
    cout << "The float rep A66667F3 in decimal form is 2791729150.\n";

    return 0;
}

