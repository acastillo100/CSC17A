#include <iostream>
#include <iomanip>

using namespace std;

struct Stats
{
    float avg;           // Average value of an integer array
    float median;        // Median value  of an integer array
    int   *mode;         // Array containing the modes
    int   nModes;        // Number of modes in the array
    int   maxFreq;       // Max frequency of modes
};

Stats ThreeM;            // Structure Variable

Stats *avgMedMode(int *, int); 
void *getArray(int *, int);
void prntArray(int*, int);
int sortAry(int *,int );
Stats printStat();

int main(int argc, char** argv) 
{
    int arySize;                     // Size of the array 
    int *Array;                      // The array holding numbers
    
    cout << "What size do you want the array to be? ";
    cin >> arySize;
       
    // Create the new array
	Array = new int[arySize];
        
        getArray(Array,arySize);
        
        sortAry(Array, arySize);
        
        cout << "Here is the array: ";
        prntArray(Array, arySize);
        cout << endl;
        
        avgMedMode (Array,arySize);
        
        printStat();

    return 0;
}

void *getArray(int *array, int size)
{
    cout << "\nPlease enter the set of numbers you want ";
	for (int i = 0; i < size; i++)
	{
	    cout << "#" << i + 1 << ": ";
	    cin >> *(array + i);
                cout << " ";
	}
}

//Uses a sort to change the array from the lowest to highest numbers.
int sortAry(int *arry,int b)
{
    int startScan;
    int minIndex;
    int minValue;
 
    for (startScan = 0; startScan < (b - 1); startScan++)
    {
        minIndex = startScan;
        minValue = *(arry + startScan);
        for (int index = startScan + 1; index < b; index++)
        {
            if (*(arry + index) < minValue)
            {
                minValue = *(arry + index);
                minIndex = index;
            }
        }
 
        *(arry + minIndex) = *(arry + startScan);
        *(arry + startScan) = minValue;
    }
  }

//Prints the array
void prntArray(int *ary, int n)
{
    for(int i=0; i < n; i++)
    {
        cout << ary[i] << " ";
    }
    cout << endl;
}

// Find out the Mean, Median, and Mode
 Stats *avgMedMode (int *arry, int size)
{
    //Finding Median
     cout << "Start." << endl;
    if(size <= 0) 
    {
        ThreeM.median = 0;     
    }
        
    
    if(size % 2 !=0) 
    {
        ThreeM.median = arry[(((size+1)/2)-1)];
    }
        
    
    else
    {
        int pos = size / 2;
        ThreeM.median = ((arry[pos] + arry[pos+1]) / 2);
    }
    
     cout << "Done with median." << endl;
     
     
    //Finding Mean
    float totSum = arry[0];
    for (int i = 1; i < size; ++i) 
    {
        totSum += arry[i];
    }
    ThreeM.avg = totSum/size;
    
    cout << "Done with mean." << endl;
    
    
//Finding Mode    
    int counter = 1;
    int max = 0;
    ThreeM.mode = new int [size];
    
    *ThreeM.mode = arry[0];
    for (int pass = 0; pass < size - 1; pass++)
      {
           if ( arry[pass] == arry[pass+1] )
           {
              counter++;
              if ( counter > max )
              {
                  max = counter;
                  *ThreeM.mode = arry[pass];
              }
           } else
               *ThreeM.mode = 0;
      }
        

 //Find Frequency of Modes       
    int freq = 0;
    int max2 = 0;
    int result;
    for (int i=0; i < size; i++)
    {
        if (*ThreeM.mode == arry[i])
            freq++;
        else
            ThreeM.maxFreq = 0;
    }
    ThreeM.maxFreq = freq;
    
    
    //Finding Number of Modes
    if (freq > max2) 
    { 
        max2 = freq; 
        result = *ThreeM.mode; // If frequency is bigger than the max ,the result 
                               // should be the number[i]
        ThreeM.nModes = freq-1;
    } 
}

Stats printStat()
{
    cout << "This is the median: " << ThreeM.median;
    cout << "\nThis is the mean: " << ThreeM.avg;
    cout << "\nThis is the mode: " << *ThreeM.mode;
    cout << "\nThis is the number of times the mode appears : " << ThreeM.maxFreq;
    cout << "\nThis is the number of modes: " << ThreeM.nModes;    
}