/* 
 * File:   main.cpp
 * Author: Alex
 *
 * Created on October 28, 2017, 10:00 PM
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <cmath>

using namespace std;

struct Balance
{
    string name;      //Name of individual
    string address;   //Address of individual
    int accNum;       //Account Number of individual
    float balance;    //Balance of individual
    float witdraw;    //Number of withdrawal for individual
    float depos;      //Number of deposits for individual
    float nBal;       //New balance number for individual
};

struct GrosPay
{
    string name;
    string sig;
    int hrsWrk;
    float payRate;
    float amount;
};

struct Stats
{
    float avg;           // Average value of an integer array
    float median;        // Median value  of an integer array
    int   *mode;         // Array containing the modes
    int   nModes;        // Number of modes in the array
    int   maxFreq;       // Max frequency of modes
};

Stats ThreeM;            // Structure Variable for Stats

int getN(int);
void Menu();
void problem1();
void findBal(Balance &);
void displayReport(Balance A);
void displayFeeHelper(float S);
void problem2();
void findAmn(GrosPay *,int);
void displayReport(GrosPay *, int );
void problem3();
Stats *avgMedMode(int *, int); 
void *getArray(int *, int);
void prntArray(int*, int);
int sortAry(int *,int );
Stats printStat();
void problem4();
void EcryptToDecrpt (int,int,int,int);
void problem5();
unsigned char factorial (int);
void problem6();
void problem7();

int main(int argc, char** argv) 
{
    int inN;
        do{
         Menu();
         inN = getN(inN);
         switch(inN){
          case 1:    problem1();break;
          case 2:    problem2();break;
          case 3:    problem3();break;
          case 4:    problem4();break;
          case 5:    problem5();break;
          case 6:    problem6();break;
          case 7:    problem7();break;
             default:   cout << "Please enter a correct number 1-7.\n";}
        }while(inN >= 1 || inN <=7 );

    return 0;
}

int getN(int inN)
{
    cout << "Please enter a number 1-7 to show the solution to a program: \n";
    cin >> inN;
    cin.ignore();
    cout << endl;
    return inN;
}

void Menu()
{
    cout << "Choice #1: Structure problem\n";
    cout << "Choice #2: Array of structures problem\n";
    cout << "Choice #3: Mean/Median/Mode problem\n";
    cout << "Choice #4: Encrypt/Decrypt problem\n";
    cout << "Choice #5: Factorial problem\n";
    cout << "Choice #6: Number Conversions\n";
    cout << "Choice #7: Extra Credit\n";

}

void problem1()
{    
    {
	Balance account {"None","None",0,0.0,0.0,0.0,0.0};
 
	findBal(account);
 
	displayReport(account);

    }
}

  //This function has the user enter the amounts actually spent in each budget   
  //category during the past month.                                             
void findBal(Balance &A)
{
    int stopOne;
    int stopTwo;
    float lose[stopOne];
    
	cout << "Who is the holder of this account? ";
	getline(cin,A.name);
	cout << "\nWhat is the address tied to the account? ";
	getline (cin,A.address);
	
        do
        {
            cout << "\nWhat is the 5 digit account number? ";
            cin  >> A.accNum;
            if (A.accNum < 10000 || A.accNum > 99999)
            {
                cout << "\nPlease enter an acceptable account number. ";
                cin >> A.accNum;
            }
        }
        while (A.accNum < 10000 || A.accNum > 99999);
        
	cout << "\nHow much was the balance at the beginning of the month? ";
	cin  >> A.balance;
        
        
	cout << "\nHow many checks were written this month? ";
	cin  >> stopOne;
        
        for (int index = 0; index < stopOne; index++)
        {
            cout << "\nHow much was written to check " << index+1 << "? ";
            cin >> lose[index];
            A.witdraw += lose[index];
        }
        
	cout << "\nHow many deposits were credited this month? ";
	cin  >> stopTwo;
        
        for (int index = 0; index < stopTwo; index++)
        {
            float gain[stopTwo];
            cout << "\nHow much was deposit " << index+1 << "? ";
            cin >> gain[index];
            A.depos += gain[index];
        } 
        
	cout << "\nThis is the total amount withdrawn: " << A.witdraw;
        cout << "\nThis is the total amount deposited: " << A.depos << endl;

}
 
                             
  //This function accepts both MonthlyBudget variables as arguments. Then it d
  //displays a report indicating the amount over or under budget the student
  //spent in each category and the amount over or under the entire budget.                                                       

void displayReport(Balance A)
{
	float totBuget, totSpnt;
 
	cout << "\n         Account Summary\n";
	cout << "------------------------------------------\n";
 
	cout << "Name:                  ";
	cout << setw(7) << A.name;
 
	cout << "\nAddress:             ";
	cout << setw(7) << A.address;
 
	cout << "\nBeginning Balance:  $";
        cout << setw(7) << A.balance;
 
	cout << "\nTotal Withdrawals:  $";
	cout << setw(7) << A.witdraw;
 
	cout << "\nTotal Deposits:     $";
	cout << setw(7) << A.depos;
        cout << endl;
        
        A.nBal = ((A.balance - A.witdraw)+ A.depos);
 
	displayFeeHelper(A.nBal);
}
 

 // This function accepts two MonthlyBudget member variables as arguments and
 // displays the amount over or under budget the student spent.
void displayFeeHelper(float S)
{
	cout << fixed << showpoint << setprecision(2);
	if (S < 0)
	{
                cout << "\nThis is the new balance." << endl;
                cout << setw(7) << "$" << S;
		cout << "\nThe account is overdrawn, a $15 fee will be applied.\n";
                cout << "\nThe balance you must pay is $" << (-1*(S-15)) << endl; 
	}
	else
	{
		cout << "This is the new balance." << endl;
                cout << setw(7) << "$" << S;
		cout << "\n The account is not overdrawn.\n\n";
	}
}

void problem2()
{
    int i;
    
    cout << "How many people? ";
    cin >> i;
    
    GrosPay user[i];
        
    findAmn(user,i);
}

  //This function has the user enter the amounts actually spent in each budget   
  //category during the past month.                                             
void findAmn(GrosPay *A,int i)
{
        
      for (int index = 0; index < i; index++)
      {
        
        cin.ignore(1000,'\n');  
        cout << "\nWhat is the user's name? ";
	getline (cin,A[index].name);
          
	
            cout << "\nHow many hours have you worked? ";
            cin  >> A[index].hrsWrk;
            if (A[index].hrsWrk < 0)
            {
                cout << "\nYou entered an unacceptable amount of hours. ";
                return;
            }
        
	cout << "\nHow much was your pay rate? ";
	cin  >> A[index].payRate;
         if (A[index].payRate < 0)
            {
                cout << "\nYou entered an unacceptable pay rate. ";
                return;
            }

        
        if (A[index].hrsWrk <= 30 && A[index].hrsWrk >= 0 )
        {
            A[index].amount = A[index].hrsWrk * A[index].payRate;
        }
        
        if (A[index].hrsWrk <= 50 && A[index].hrsWrk > 30 )
        {
            A[index].amount = (30*A[index].payRate)+2*((A[index].hrsWrk-30)*A[index].payRate);
        }
        
        if (A[index].hrsWrk > 50 )
        {
            A[index].amount = (30*A[index].payRate)+(2*(20*A[index].payRate))+(3*((A[index].hrsWrk-50)*A[index].hrsWrk));
        }
        
        cout << endl;
        
        displayReport(A,index);
      }
}
 
                             
  //This function accepts both  variables as arguments. Then it d
  //displays a 
  //                                                      
void displayReport(GrosPay *A, int index)
{
	cout << "Company                  ";
 
	cout << "\nAddress                ";
 
	cout << "\nName:                  ";
        cout << setw(7) << A[index].name;
 
	cout << "\nAmount (Numerical):   $";
	cout << setw(7) << A[index].amount;
 
	cout << "\nAmount (English):     $";
       
        cout << "\nSignature:             \n\n";
}

void problem3()
{
    int arySize;                     // Size of the array 
    int *Array;                      // The array holding numbers
    
    cout << "What size do you want the array to be? ";
    cin >> arySize;
       
    // Create the new array
	Array = new int[arySize];
        
        getArray(Array,arySize);
        
        sortAry(Array, arySize);
        
        cout << "Here is the array: ";
        prntArray(Array, arySize);
        cout << endl;
        
        avgMedMode (Array,arySize);
        
        printStat();  
        
        delete []Array;
}

void *getArray(int *array, int size)
{
    cout << "\nPlease enter the set of numbers you want ";
	for (int i = 0; i < size; i++)
	{
	    cout << "#" << i + 1 << ": ";
	    cin >> *(array + i);
                cout << " ";
	}
}

//Uses a sort to change the array from the lowest to highest numbers.
int sortAry(int *arry,int b)
{
    int startScan;
    int minIndex;
    int minValue;
 
    for (startScan = 0; startScan < (b - 1); startScan++)
    {
        minIndex = startScan;
        minValue = *(arry + startScan);
        for (int index = startScan + 1; index < b; index++)
        {
            if (*(arry + index) < minValue)
            {
                minValue = *(arry + index);
                minIndex = index;
            }
        }
 
        *(arry + minIndex) = *(arry + startScan);
        *(arry + startScan) = minValue;
    }
  }

//Prints the array
void prntArray(int *ary, int n)
{
    for(int i=0; i < n; i++)
    {
        cout << ary[i] << " ";
    }
    cout << endl;
}

// Find out the Mean, Median, and Mode
 Stats *avgMedMode (int *arry, int size)
{
    //Finding Median
    if(size <= 0) 
    {
        ThreeM.median = 0;     
    }
        
    
    if(size % 2 !=0) 
    {
        ThreeM.median = arry[(((size+1)/2)-1)];
    }
        
    
    else
    {
        int pos = size / 2;
        ThreeM.median = ((arry[pos] + arry[pos+1]) / 2);
    }
    
     
     
    //Finding Mean
    float totSum = arry[0];
    for (int i = 1; i < size; ++i) 
    {
        totSum += arry[i];
    }
    ThreeM.avg = totSum/size;
    
    
    
//Finding Mode    
    int counter = 1;
    int max = 0;
    ThreeM.mode = new int [size];
    
    *ThreeM.mode = arry[0];
    for (int pass = 0; pass < size - 1; pass++)
      {
           if ( arry[pass] == arry[pass+1])
           {
              counter++;
              if ( counter > max )
              {
                  max = counter;
                  *ThreeM.mode = arry[pass];
              }
              else
                  *ThreeM.mode = 0;
           } 
           else
               counter = 1;
      }
        

 //Find Frequency of Modes       
    int freq = 0;
    int max2 = 0;
    int result;
    for (int i=0; i < size; i++)
    {
        if (*ThreeM.mode == arry[i])
            freq++;
        else
            ThreeM.maxFreq = 0;
    }
    ThreeM.maxFreq = freq;
    
    
    //Finding Number of Modes
    if (freq > max2) 
    { 
        max2 = freq; 
        result = *ThreeM.mode; // If frequency is bigger than the max ,the result 
                               // should be the number[i]
        ThreeM.nModes = freq-1;
    } 
}

Stats printStat()
{
    cout << "This is the median: " << ThreeM.median;
    cout << "\nThis is the mean: " << ThreeM.avg;
    cout << "\nThis is the mode: " << *ThreeM.mode;
    cout << "\nThis is the number of times the mode appears : " << ThreeM.maxFreq;
    cout << "\nThis is the number of modes: " << ThreeM.nModes;    
    cout << "\n\n";
}

void problem4()
{
    int output;
        int code;
        string decrypt;
        char holder[4];

	// Ask user to enter the message to decrypt
	cout << "Enter a 4 integer piece of data (Integers from 0 to 7): ";
	getline(cin,decrypt);
        
        if (decrypt.length() != 4)
        {
            cout << "\nPlease reenter data with 4 integers: ";
            getline(cin,decrypt);    
        }
        
    do
    {
        for(int index = 0; index < 4; index++)
          {
                if (decrypt[index] < '0' || decrypt[index] >= '8')
                {
                    cout << endl << decrypt[index] << " is invalid. You cannot ";
                    cout << "have values less than 0, 8 or 9.";
                    output = 0;
                }
                else
                {
                	output = 1;
                }
                
          }
        if (output == 0)
        {
            cout << "\nPlease reenter data: ";
            getline(cin,decrypt);
            cout << endl;
        }
        else
        {
        	output = 1;
        }
    }
        while (output == 0);

        cout << endl;
        
        stringstream number(decrypt);
        number >> code;
        
        for(int index = 0; index < 4; index++)
        {
        	 holder[index] = (static_cast<int>(decrypt[index]));
        	
        	if (index == 3) 
        	{
        	  cout << endl;
        	  holder[0] = (static_cast<int>(decrypt[0]));
        	  holder[1] = (static_cast<int>(decrypt[1]));
        	  holder[2] = (static_cast<int>(decrypt[2]));
        	  holder[3] = (static_cast<int>(decrypt[3]));
	          int a = ((holder[0]+5) % 8);
	          int b = ((holder[1]+5) % 8);
	          int c = ((holder[2]+5) % 8);
	          int d = ((holder[3]+5) % 8);
	          cout << "This is the message decrypted." << endl;
	          cout << c << d << a << b << endl;
	          index++;
                  
                  EcryptToDecrpt(a,b,c,d);
        	}        	
        }
}

void EcryptToDecrpt (int first, int second, int third, int fourth)
{
    //Swap int array back to the message switched
    int message[4] = {third,fourth,first,second};   
    
    int temp = message[0];
    int tempTw = message[1];
    
    message[0] = message[2];
    message[2] = temp;
    
    message[1] = message[3];
    message[3] = tempTw;

    
    //Change for all possibilities
    if (message[0] == 0)
        message [0] = 3;
    else if (message[0] == 1)
        message[0] = 4;        
    else if (message[0] == 2)
        message[0] = 5;            
    else if (message[0] == 3)
        message[0] = 6;               
    else if (message[0] == 4)
        message[0] = 7;    
    else if (message[0] == 5)
        message[0] = 0;   
    else if (message[0] == 6)
        message[0] = 1;                
    else
        message[1] = 2;
        
    if (message[1] == 0)
        message [1] = 3;
    else if (message[1] == 1)
        message[1] = 4;        
    else if (message[1] == 2)
        message[1] = 5;            
    else if (message[1] == 3)
        message[1] = 6;               
    else if (message[1] == 4)
        message[1] = 7;    
    else if (message[1] == 5)
        message[1] = 0;   
    else if (message[1] == 6)
        message[1] = 1;                
    else
        message[1] = 2;
    
    if (message[2] == 0)
        message [2] = 3;
    else if (message[2] == 1)
        message[2] = 4;        
    else if (message[2] == 2)
        message[2] = 5;            
    else if (message[2] == 3)
        message[2] = 6;               
    else if (message[2] == 4)
        message[2] = 7;    
    else if (message[2] == 5)
        message[2] = 0;   
    else if (message[2] == 6)
        message[2] = 1;                
    else
        message[2] = 2;
    
    if (message[3] == 0)
        message [3] = 3;
    else if (message[3] == 1)
        message[3] = 4;        
    else if (message[3] == 2)
        message[3] = 5;            
    else if (message[3] == 3)
        message[3] = 6;               
    else if (message[3] == 4)
        message[3] = 7;    
    else if (message[3] == 5)
        message[3] = 0;   
    else if (message[3] == 6)
        message[3] = 1;                
    else
        message[3] = 2;
    
    cout << "\nThis is the encrypted message decrypted: ";
    for (int index = 0; index < 4; index++)
    cout << message[index];
    cout << "\n\n";
}

void problem5()
{
   int t;
    unsigned char ans;
    cout << fixed << showpoint << setprecision(2);
    for(t=1; t <= 10; t++)
    {
        cout << "Factorial of " << t << " is : ";
        ans = factorial(t);
        cout << ans;
        cout << endl;
    }
    
   cout << "Unsigned/Signed char is ends after !4, Unsigned/Signed int ends after"; 
   cout << "!15, Short int ends after !7 and Long int ends after !13.\n"; 
   cout << "Signed short ends after !7 and Unsigned short ends after !8.\n";
   cout << "Unsigned long ends after !13, Signed long ends after !13,"; 
   cout << "Long long int ends after !20, Unsigned long long int ends after !22.\n";
   cout << "Float ends after !34 and double ends after !170.\n\n"; 
}

unsigned char factorial(int n)
{
    unsigned char ans = 1.0;
    int i;
    for(i=1; i <= n; i++)
    {
        ans *= i;
    }
    return ans;
}

void problem6()
{
    cout << "2.875 in base 10 is: 10.111 in base 2, 2.7 in base 8, and";
    cout << " 2.E in base 16.\n\n";
    cout << "0.1796875 in base 10 is: 10.111 in base 2, 0.134 in base 8, and";
    cout << " 0.2E in base 16.\n\n";
    cout << "-2.875 in base 10 is: 1.001 in base 2, 1.000406111 in base 8, and";
    cout << " 1.00418937 in base 16.\n\n";
    cout << "-0.1796875 in base 10 is: 0.1101001 in base 2, 0.07027 in base 8, and";
    cout << " 0.1C2F8516 in base 16.\n\n";
    cout << "The float rep 59999901 in decimal form is 1503238401.\n";
    cout << "The float rep 59999902 in decimal form is 1503238402.\n";    
    cout << "The float rep A66667F3 in decimal form is 2791729150.\n\n";   
}

void problem7()
{
    cout << "Nothing , because I did not do it.\n\n";
}