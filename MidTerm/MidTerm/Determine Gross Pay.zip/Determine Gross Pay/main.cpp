#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
 
struct GrosPay
{
    string name;
    string sig;
    int hrsWrk;
    float payRate;
    float amount;
};
 
// Function Prototypes
 void findAmn(GrosPay *,int);
void displayReport(GrosPay *, int );
 

int main(int argc, char** argv)
{

    int i;
    
    cout << "How many people? ";
    cin >> i;
    
    GrosPay user[i];
        
    findAmn(user,i);
	return 0;
}
 

  //This function has the user enter the name, hours worked, and pay rate 
  //to determine amount to be paid                                 
void findAmn(GrosPay *A,int i)
{
        
      for (int index = 0; index < i; index++)
      {
        
        cin.ignore(1000,'\n');  
        cout << "\nWhat is the user's name? ";
	getline (cin,A[index].name);
          
	
            cout << "\nHow many hours have you worked? ";
            cin  >> A[index].hrsWrk;
            if (A[index].hrsWrk < 0)
            {
                cout << "\nYou entered an unacceptable amount of hours. ";
                return;
            }
        
	cout << "\nHow much was your pay rate? ";
	cin  >> A[index].payRate;
         if (A[index].payRate < 0)
            {
                cout << "\nYou entered an unacceptable pay rate. ";
                return;
            }

        
        if (A[index].hrsWrk <= 30 && A[index].hrsWrk >= 0 )
        {
            A[index].amount = A[index].hrsWrk * A[index].payRate;
        }
        
        if (A[index].hrsWrk <= 50 && A[index].hrsWrk > 30 )
        {
            A[index].amount = (30*A[index].payRate)+2*((A[index].hrsWrk-30)*A[index].payRate);
        }
        
        if (A[index].hrsWrk > 50 )
        {
            A[index].amount = (30*A[index].payRate)+(2*(20*A[index].payRate))+(3*((A[index].hrsWrk-50)*A[index].hrsWrk));
        }
        
        cout << endl;
        
        displayReport(A,index);
      }
}
 
                             
  //This function accepts both the structure and amount of structures as arguments. 
  //then it displays a name, amount and signature                                                      
void displayReport(GrosPay *A, int index)
{
	cout << "Company                  ";
 
	cout << "\nAddress                ";
 
	cout << "\nName:                  ";
        cout << setw(7) << A[index].name;
 
	cout << "\nAmount (Numerical):   $";
	cout << setw(7) << A[index].amount;
 
	cout << "\nAmount (English):     $";
       
        cout << "\nSignature:             ";
}