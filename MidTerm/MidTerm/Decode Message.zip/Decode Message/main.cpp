#include <iostream>
#include <string>
#include <sstream>
#include <cmath>
using namespace std;


void EcryptToDecrpt (int,int,int,int);

int main(int argc, char** argv)
{
        int output;
        int code;
        string decrypt;
        char holder[4];

	// Ask user to enter the message to decrypt
	cout << "Enter a 4 integer piece of data (Integers from 0 to 7): ";
	getline(cin,decrypt);
        
        if (decrypt.length() != 4)
        {
            cout << "\nPlease reenter data with 4 integers: ";
            getline(cin,decrypt);    
        }
        
    do
    {
        for(int index = 0; index < 4; index++)
          {
                if (decrypt[index] < '0' || decrypt[index] >= '8')
                {
                    cout << endl << decrypt[index] << " is invalid. You cannot ";
                    cout << "have values less than 0, 8 or 9.";
                    output = 0;
                }
                else
                {
                	output = 1;
                }
                
          }
        if (output == 0)
        {
            cout << "\nPlease reenter data: ";
            getline(cin,decrypt);
            cout << endl;
        }
        else
        {
        	output = 1;
        }
    }
        while (output == 0);

        cout << endl;
        
        stringstream number(decrypt);
        number >> code;
        
        for(int index = 0; index < 4; index++)
        {
        	 holder[index] = (static_cast<int>(decrypt[index]));
        	
        	if (index == 3) 
        	{
        	  cout << endl;
        	  holder[0] = (static_cast<int>(decrypt[0]));
        	  holder[1] = (static_cast<int>(decrypt[1]));
        	  holder[2] = (static_cast<int>(decrypt[2]));
        	  holder[3] = (static_cast<int>(decrypt[3]));
	          int a = ((holder[0]+5) % 8);
	          int b = ((holder[1]+5) % 8);
	          int c = ((holder[2]+5) % 8);
	          int d = ((holder[3]+5) % 8);
	          cout << "This is the message decrypted." << endl;
	          cout << c << d << a << b << endl;
	          index++;
                  
                  EcryptToDecrpt(a,b,c,d);
        	}        	
        }
	return 0;
}

void EcryptToDecrpt (int first, int second, int third, int fourth)
{
    //Swap int array back to the message switched
    int message[4] = {third,fourth,first,second};   
    
    int temp = message[0];
    int tempTw = message[1];
    
    message[0] = message[2];
    message[2] = temp;
    
    message[1] = message[3];
    message[3] = tempTw;

    
    //Change for all possibilities
    if (message[0] == 0)
        message [0] = 3;
    else if (message[0] == 1)
        message[0] = 4;        
    else if (message[0] == 2)
        message[0] = 5;            
    else if (message[0] == 3)
        message[0] = 6;               
    else if (message[0] == 4)
        message[0] = 7;    
    else if (message[0] == 5)
        message[0] = 0;   
    else if (message[0] == 6)
        message[0] = 1;                
    else
        message[1] = 2;
        
    if (message[1] == 0)
        message [1] = 3;
    else if (message[1] == 1)
        message[1] = 4;        
    else if (message[1] == 2)
        message[1] = 5;            
    else if (message[1] == 3)
        message[1] = 6;               
    else if (message[1] == 4)
        message[1] = 7;    
    else if (message[1] == 5)
        message[1] = 0;   
    else if (message[1] == 6)
        message[1] = 1;                
    else
        message[1] = 2;
    
    if (message[2] == 0)
        message [2] = 3;
    else if (message[2] == 1)
        message[2] = 4;        
    else if (message[2] == 2)
        message[2] = 5;            
    else if (message[2] == 3)
        message[2] = 6;               
    else if (message[2] == 4)
        message[2] = 7;    
    else if (message[2] == 5)
        message[2] = 0;   
    else if (message[2] == 6)
        message[2] = 1;                
    else
        message[2] = 2;
    
    if (message[3] == 0)
        message [3] = 3;
    else if (message[3] == 1)
        message[3] = 4;        
    else if (message[3] == 2)
        message[3] = 5;            
    else if (message[3] == 3)
        message[3] = 6;               
    else if (message[3] == 4)
        message[3] = 7;    
    else if (message[3] == 5)
        message[3] = 0;   
    else if (message[3] == 6)
        message[3] = 1;                
    else
        message[3] = 2;
    
    cout << "\nThis is the encrypted message decrypted: ";
    for (int index = 0; index < 4; index++)
    cout << message[index];
}