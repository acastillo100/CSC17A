// unsigned/signed char is 4 unsigned/signed int is 15, short int is 7, long int is 13, 
//signed short is 7, unsigned short is 8, unsigned long is 13, signed long is 13, 
// long long int is 20, unsigned long long int is 22, float is 34, double is 170

#include<iostream>
#include <iomanip>

using namespace std;

unsigned char factorial (int);

int main(int argc, char** argv)
{
    int t;
    unsigned char ans;
    cout << fixed << showpoint << setprecision(2);
    for(t=1; t <= 50; t++)
    {
        cout << "Factorial of " << t << " is : ";
        ans = factorial(t);
        cout << ans;
        cout << endl;
    }
    return 0;
}

unsigned char factorial(int n)
{
    unsigned char ans = 1.0;
    int i;
    for(i=1; i <= n; i++)
    {
        ans *= i;
    }
    return ans;
}