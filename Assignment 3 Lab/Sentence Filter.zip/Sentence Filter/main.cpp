//Alex Castillo                 CSC17A                 Chapter 12, P.707, #7
//
/***************************************************************************
* FILTER AND PRINT SENTENCE
* __________________________________________________________________________
* This function asks the user for two file names. The first file will be 
* opened for input and the second file will be opened for output. The 
* program will then read the contents of the first file and change all the 
* letters to lowercase except the first letter of each sentence, which 
* should be made uppercase. The revised contents are then stored in the 
* second file.
* 
* **************************************************************************
* INPUT
* 
* readFile	        : The file used to read the sentences from
* outFile		: The file that outputs the info from readFile
* 
* OUTPUT
* 
* oFile                 : Text File that outputs the sentence
* 
* ______________________________________________________________________________
*******************************************************************************/
 
#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
using namespace std;

int main(int argc, char** argv)
{
    ifstream inFile;
    ofstream oFile;
    string readFile,
           outFile,
           line;
    char sent;
    
    cout << "Please enter the name (along with file type) of the file you\n"
         << "would like to open for output." << endl;
    cin >> outFile;
     
   oFile.open(outFile);  
    
    cout << "Please enter the name (along with file type) of the file you\n"
         << "would like to open for input." << endl;  
    cin >> readFile;

    
    inFile.open(readFile);

    
    if (inFile)
   {
       inFile.get(sent);

       // Write uppercase char to output file.
       oFile.put(toupper(sent));

       while (inFile)
       {
           if (sent != '\0')
           {
               // Read another char from file 1.
                inFile.get(sent);
                oFile.put(tolower(sent));
           

            if (sent == '\n')
            {
                inFile.get(sent);
                oFile.put(toupper(sent));
              
            }
                 
            if (sent == '.')
            {
                inFile.get(sent);
                oFile.put(sent);
              
               if(sent == ' ')
               {
                   inFile.get(sent);
                   oFile.put(toupper(sent));
               }
              
               else if (sent == '\n')
               {
                   inFile.get(sent);
                   oFile.put(sent);
               }

            }
          }
       }
    }

     else
      {
          cout << "Not able to open.";
      }
    
    inFile.close();
    oFile.close();
    
    return 0;
}
