//Alex Castillo                CSC17A                 Chapter 12, P.708, #10
//
/***************************************************************************
* FILE DECRYPTION FILTER
* __________________________________________________________________________
* This function workS like a filter, reading the contents of one file, 
* translating the data of a code, and then writing the coded contents out 
* to a second file. The second file will be a version of the first file, 
* but written in the original state.
* 
* **************************************************************************
* INPUT
* 
* decrypt	        : The file used to read the message from
* output		: The file that outputs the info from decrpt.txt
* 
* OUTPUT
* 
* oFile                 : Text File that outputs the message
* 
* ______________________________________________________________________________
*******************************************************************************/
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main(int argc, char** argv)
{
	string output, decrypt;
	char mess;

	// Ask user to enter the name of file to decrypt
	cout << "Enter name of file to decrypt: ";
	cin  >> decrypt;
        cout << endl;

	fstream inFile(decrypt, ios::in);
	if (!inFile)
	{
		cout << "Error opening file \"" << decrypt << "\".\n";
		return 0;
	}

	cout << "Enter name for decrypted file: ";
	cin >> output;
	fstream oFile(output, ios::out);

	while (!inFile.fail())
	{
		inFile.get(mess);
		mess -= 10;
		oFile << mess;
	}

        if (inFile)
        {
            cout << "Message encrypted!\n";
        }
	inFile.close();
	oFile.close();
	return 0;
}