//Alex Castillo		           CSC17A		 Chapter 10, P. 593, #04
//
/*******************************************************************************
 *
 * DISPLAY NUMBER OF WORDS AND AVAERAGE LETTERS
 * _____________________________________________________________________________
 * This function accepts a pointer to a C-string as an argument and returns the
 * number of words contained in the string. The number of words is then 
 * displayed on the screen.
 *____________________________________________________________________________
 * INPUT
 *  cString                     : User inputed string
 * 	
 * OUTPUT
 *  numOfWords			: The number of words
 *  avgLets                     : Average number of letters per word
 *
 ******************************************************************************/
#include <cstring>
#include <iostream>
#include <string>
using namespace std;
 
//function prototype
int sngSize(char*, const int, int&);
 
int main(int argc, char** argv)
{
    const int maxChar = 101;                  //Max number for string
    char cString[maxChar];                    //Pointer to a C-string
    int letters = 0;                          //Letters in word
    float avgLets;                            //Average letters
    int numWords;	                      // The number of words
    
    cout << "Please enter a sentence (100 letters or less) and I was tell you "
            << "how many words are in the sentence." << endl;
    cin.getline(cString,maxChar);
    

//Call in function, in order to set numWords equal to the number of words
	numWords = sngSize(cString,maxChar,letters);
        
        avgLets = static_cast<float>(letters) / numWords;

 
//Output
	cout << endl << numWords << " is the amount of words in this string." << endl;
        cout << "\nThe average number of letters in each word is" << " : "
        << avgLets << endl;
 
	return 0;
}
 
//******************************************************************************
// Definition of function stringSize
// This function accepts a pointer to a string as an argument. It uses a while
// to find spaces between words to determine how many words there are in the
// string.
//******************************************************************************
int sngSize(char* cstr, const int max, int &leters)
{
   //Initialize Variable
    int words = 1;

    //Find Spaces
    for(int i = 0; i < max; i++)
    {
        if(isspace(cstr[i]))
        {
            words++;
        }
    }
    
    //Find Length
    leters = strlen(cstr);
    leters = leters - (words - 1);
    
    return words;
}