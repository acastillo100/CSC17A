//Alex Castillo                 CSC17A                 Chapter 10, P.595, #6
//
/***************************************************************************
* DISPLAY CONSONANTS AND VOWELS 
* __________________________________________________________________________
* This function accepts a pointer to a C-string as its argument then 
* counts the number of vowels appearing in the string and returns that number.
*  It also accepts a pointer to a counts the number of consonants that
* appear in the string and returns that number. A menu is shown to let
* the user decide what to do.
* 
* **************************************************************************
* INPUT
* 
* List[Length]	        : C-string that contains data entered by the user
* choice		: Holds menu user input
* 
* OUTPUT
* 
* countV and/or countC  : Number of vowels and/or consonants in the string
* 
* ______________________________________________________________________________
*******************************************************************************/
 
#include <iostream>
#include <string>
#include <cstring>
using namespace std;
 
int countV(char *);
int countC(char *);
 
int main(int argc, char** argv)
{
	
    const int length = 101;     //Max length of string
    char list[length],          //Char string to hold user string
	     choice;		// Holds menu user input.
 
 
	// Ask the user to enter a string
	cout << "Enter a string of no more than "
	     << length-1 << " characters:\n";
	cin.getline(list, length);
 
	do
	{
		cout << "\t\t\t\tProgram menu\n";
		cout << "A) Count the number of vowels in the string\n";
		cout << "B) Count the number of consonants in the string\n";
		cout << "C) Count both the vowels and consonants in the string\n";
		cout << "D) Enter another string\n";
		cout << "E) Exit the program\n";
		cin  >> choice;
		choice = toupper(choice);
 
		switch (choice)
		{
			case 'A' : cout << "There are " << countV(list)
							<< " vowels in the string: "
							<< list << endl;
						break;
			case 'B' : cout << "There are " << countC(list)
							<< " consonants in the string: "
							<< list << endl;
					    break;
			case 'C' : cout << "There are "
							<< (countV(list) + countC(list))
							<< " consonants and vowels in the string: "
							<< list << endl;
						break;
			case 'D' : cout << "Enter another string of no more than "
		 					<< length-1 << " characters:\n";
		 				cin.ignore();
		 			   cin.getline(list, length);
		}
 
 
	} while (choice != 'E');
}
 

// This function accepts a C-string as its argument. The function counts the   
// number of vowels appearing in the string and returns that number.      
int countVowels(char *Ch)
{
	int count = 0;
 
	for (int i = 0; i < strlen(Ch); i++)
	{
		if (toupper(Ch[i]) == 'A' || 
			toupper(Ch[i]) == 'E' ||
			toupper(Ch[i]) == 'I' ||
			toupper(Ch[i]) == 'O' ||
			toupper(Ch[i]) == 'U'
		   )
			count++;
	}
	return count;
}
 
                                                           
// This function accepts a C-string as its argument. The function counts the   
// number of consonants appearing in the string and returns that number.       
int countConsonants(char *Ch)
{
	int count = 0;
 
	for (int i = 0; i < strlen(Ch); i++)
	{
		if (isalpha(Ch[i]))
			count++;
	}
 
	return count - countVowels(Ch);
}

