//Alex Castillo                 CSC17A                 Chapter 12, P.708, #9
//
/***************************************************************************
* FILE ENCRYPTION FILTER
* __________________________________________________________________________
* This function workS like a filter, reading the contents of one file, 
* modifying the data into a code, and then writing the coded contents out 
* to a second file. The second file will be a version of the first file, 
* but written in a secret code.
* 
* **************************************************************************
* INPUT
* 
* ecrypt	        : The file used to read the message from
* decrypt		: The file that outputs the info from encrpt.txt
* 
* OUTPUT
* 
* oFile                 : Text File that outputs the message
* 
* ______________________________________________________________________________
*******************************************************************************/
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main()
{
	string ecrypt, decrypt;
	char mess;

	// Ask user to enter the name of file to decrypt
	cout << "Enter name of file to decrypt: ";
	cin  >> ecrypt;
        cout << endl;

	fstream inFile(ecrypt, ios::in);
	if (!inFile)
	{
		cout << "Error opening file \"" << ecrypt << "\".\n";
		return 0;
	}

	cout << "Enter name for decrypted file: ";
	cin  >> decrypt;
	fstream oFile(decrypt, ios::out);

	while (!inFile.fail())
	{
		inFile.get(mess);
		mess += 10;
		oFile << mess;
	}

        if (inFile)
        {
            cout << "Message encrypted!\n";
        }
	inFile.close();
	oFile.close();
	return 0;
}
