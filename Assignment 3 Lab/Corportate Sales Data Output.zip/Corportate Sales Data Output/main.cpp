//Alex Castillo                 CSC17A                 Chapter 12, P.708, #9
//
/***************************************************************************
* FILE ENCRYPTION FILTER
* __________________________________________________________________________
* This function uses a structure to store the following data on a company 
* division: Division Name (such as East, West, North, or South), quarter 
* (1, 2, 3, or 4), and quarterly sales. The user then is asked for the four 
* quarters’ sales figures for the East, West, North, and South divisions. 
* The data for each quarter for each division should be written to a file.
* 
* **************************************************************************
* INPUT
* 
* Sales.QrtlySale	: Sales for each quarter
* 
* OUTPUT
* 
* Sales.Qtr             : Output for each quarter sale in each division
* 
* ______________________________________________________________________________
*******************************************************************************/

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main()
{
        const int LENGTH = 4;
        struct CorpData
       {
	string Division[LENGTH] = {"East", "West", "North", "South"};
	float Qtr[LENGTH];
	float QtrlySale[LENGTH];
       };

 	CorpData Sales[LENGTH];
        fstream sFile;
        
        
        sFile.open("salefigures.txt", ios::out);
 	if (!sFile)
 	{
 		cout << "Error opening file. Program aborting.\n";
 		return 0;
 	}

 	// Ask for the four quarters' sales figures
 	cout << "Enter the quarterly sales figures for each of the divisions:\n";
 	for (int d = 0; d < LENGTH; d++)
 	{
 		cout << Sales[d].Division[d] << "\nDivision:\n";
 		for (int q = 0; q < LENGTH; q++)
 		{
 			do
 			{
 				cout << "Quarter " << (q + 1) << ": ";
 				cin >> Sales[d].QtrlySale[q];
                                cout << endl;
 				if (Sales[d].QtrlySale[q] < 0)
 				cout << "Sales figures must be greater than 0.\n";
 			} while (Sales[d].QtrlySale[q] < 0);
 			Sales[d].Qtr[q] = Sales[d].QtrlySale[q];
 		}
                
        }
                
                
        for (int p = 0; p < LENGTH; p++)
 	{
 		sFile << Sales[p].Division[p] << "\nDivision:\n";
 		for (int w = 0; w < LENGTH; w++)
 		{
 				sFile << "Quarter " << (w + 1) << ": ";
 				sFile << Sales[p].Qtr[w];
                                sFile << endl;
 		}
 	}

 	sFile.close();
 	return 0;
}