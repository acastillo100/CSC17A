//Alex Castillo             CSC17A         Chapter 10, P. 595, #7
//
/****************************************************************
 *
 * REARRANGE FULL NAME
 * ______________________________________________________________
 * This program accepts a user's name, which is formatted as, 
 * First name, Middle name, Last name. It is calculated  as input 
 * then rearranges the name to fit a last name, middle name, and
 * then first name format.
 * ______________________________________________________________
 * CONSTANTS
 * 	maximum         : Maximum string size
 *
 * INPUT
 * 	first           : First name
 * 	middle          : Middle name
 * 	last            : Last name
 * 	nameIndex       : First/Middle/Last name index
 * 	fullIndex       : Full name index
 *
 * OUTPUT
 * 	full            : Rearranged full name
 *
 ***************************************************************/
#include <iostream>
using namespace std;
 
int main(int argc, char** argv)
{
	const int maximum = 30;                // Maximum string size
 
	char first[maximum];                   // First name
	char middle[maximum];                  // Middle name
	char last[maximum];                    // Last name
	int nameDex = 0;                     // First/Middle/Last name index
	int fullDex = 0;                     // Full name index
	char full[maximum * 3];                // Full name index
 
	// Prompt user for name -- First, Middle, Last
	cout << "Your Name (First Middle Last): ";
	cin >> first >> middle >> last;
 
	// Load last name into output array
	while (last[nameDex] != '\0')
	{
		full[fullDex] = last[nameDex];
		fullDex++;
		nameDex++;
	}
	nameDex = 0;
 
	// Load comma after last name into output array
	full[fullDex] = ',';
	fullDex++;
	full[fullDex] = ' ';
	fullDex++;
 
	// Load first name into output array
	while (first[nameDex] != '\0')
	{
		full[fullDex] = first[nameDex];
		fullDex++;
		nameDex++;
	}
	nameDex = 0;
	full[fullDex] = ' ';
	fullDex++;
 
	// Load middle name into output array
	while (middle[nameDex] != '\0')
	{
		full[fullDex] = middle[nameDex];
		fullDex++;
		nameDex++;
	}
 
	// Add null terminator to full name array
	full[fullDex] = '\0';
 
	// Reset output array index
	fullDex = 0;
 
	// Rearranged name
	cout << "\nYour altered name (Last, Middle First): ";
	while (full[fullDex] != '\0')
	{
		cout << full[fullDex];
		fullDex++;
	}
 
	return 0;
}