//Alex Castillo		           CSC17A		 Chapter 10, P. 593, #03
//
/*******************************************************************************
 *
 * DISPLAY NUMBER OF WORDS IN A STRING
 * _____________________________________________________________________________
 * This function accepts a pointer to a C-string as an argument and returns the
 * number of words contained in the string. The number of words is then 
 * displayed on the screen.
 *____________________________________________________________________________
 * INPUT
 *  cString                     : User inputed string
 * 	
 * OUTPUT
 *  numOfWords			: the number of words
 *
 ******************************************************************************/
#include <cstring>
#include <iostream>
#include <string>
using namespace std;
 
//function prototype
int sngSize(char*, const int);
 
int main(int argc, char** argv)
{
    const int maxChar = 101;                  //Max number for string
    char cString[maxChar];                    //Pointer to a C-string
    
    cout << "Please enter a sentence (100 letters or less) and I was tell you "
            << "how many words are in the sentence." << endl;
    cin.getline(cString,maxChar);
    
 
    int numWords;	// The number of words
 
//Call in function, in order to set numWords equal to the number of words
	numWords = sngSize(cString,maxChar);
 
//Output
	cout << endl << numWords << " is the amount of words in this string." << endl;
 
	return 0;
}
 
//******************************************************************************
// Definition of function stringSize
// This function accepts a pointer to a string as an argument. It uses a while
// to find spaces between words to determine how many words there are in the
// string.
//******************************************************************************
int sngSize(char* cstr, const int max)
{
    int words;
 
    //Initialize Variable
    words = 1;
 
    //Find Spaces
    for(int i = 0; i < max; i++)
    {
        if(isspace(cstr[i]))
        {
            words++;
        }
    }
    return words;
}