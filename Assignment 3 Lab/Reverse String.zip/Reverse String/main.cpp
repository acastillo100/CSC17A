//Alex Castillo           CSC17A           Chapter 10, P. 594, #2
//
/****************************************************************
 *
 * REVERSE A CHARACTER STRING
 * ______________________________________________________________
 * This program accepts as input a string of characters, then
 * displays the string characters in a backwards order.
 * ______________________________________________________________
 * CONSTANTS
 *  maximum         : Maximum input string size
 *
 * INPUT
 *  wordString      : C-string
 * 
 * OUTPUT
 *  backwardString  : Original string backwards
 *
 ***************************************************************/
#include <iostream>
using namespace std;
 
int main(int argc, char** argv)
{
	const int maximum = 31;            // Maximum string size
 
	char wordStr[maximum];             // C-string
	char i = 0;                        // counter variable
 
	// Prompt user for C-string
	cout << "Please enter a word less than " << maximum-1 
             << " and it was be reversed.";
	cin.getline(wordStr, maximum);
	cout << endl;
 
	// Locate end of C-string
	while (wordStr[i] != '\0')
		i++;
	i--;
 
	// Output backwards C-string
	while (i >= 0)
	{
            cout << "This is your word backwards: ";
            cout << wordStr[i];
	    i--;
	}
 
	return 0;
}