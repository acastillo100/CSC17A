//Alex Castillo                 CSC17A                 Chapter 12, P.706, #3
//
/***************************************************************************
* SHOW JOKE PUNCH LINE
* __________________________________________________________________________
* This function reads and prints a joke and its punch line from two different 
* files. The first file contains a joke, but not its punch line. The second 
* file has the punch line as its last line, preceded by “garbage.”
* 
* **************************************************************************
* INPUT
* 
* joke  	        : The file used to read the joke
* punchline             : The punchline of a joke
* 
* OUTPUT
* 
* joke                  : The full joke and punchline
* 
* ______________________________________________________________________________
*******************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Function prototype
void Joke(fstream &);
void Punchline(fstream &);

int main(int argc, char** argv)
{
	fstream joke("jokeFile.txt", ios::in);
	if (!joke)
	{
		cout << "Error opening file jokeFile.txt\n";
		return 0;
	}
	fstream pline("punchline.txt", ios::in);
	if (!pline)
	{
		cout << "Error opening file punchline.txt.\n";
		return 0;
	}

	Joke(joke);
	Punchline(pline);
	return 0;
}


                                                              
//Reads and displays each line in the file it is passed.
void Joke(fstream &joke)
{
	string next;
	while (getline(joke, next))
	{
		cout << next << endl;
	}
}


                                                          
//Displays only the last line of the file it is passed.           
void Punchline(fstream &pline)
{
	string next;
	pline.seekg(-10L, ios::end);
	getline(pline, next);
	cout << next << endl;
}