//Alex Castillo                  CSC-17A                  Chapter 3, P. 144, #13
//
/*****************************************************************************
 *
 * Convert USD to Yen and Euros  
 * __________________________________________________________________________
 * 
 * This program accepts a user inputed number for the number of dollars and 
 * the program outputs the amount, converting it to Japanese Yen and European
 * Euros as well. The output for currency is in fixed-point notation with two
 * decimal places. 
 * 
 * Computation is based on the formula:
 * 
 * yenAmn = Dollar * yenCon
 * eurAmn = Dollar * eurCon  
 * __________________________________________________________________________
 * 
 * INPUT
 * Dollar                                   : The currency in USD  
 * 
 * OUTPUT
 * yenAmn                                   : The currency in Yen
 * eurAmn                                   : The currency in Euros
 ****************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;
 
/*
 * 
 */
int main(int argc, char** argv) 
{
 
    int Dollar;                          // USD Dollar for user input
    float yenAmn, eurAmn;                // Yen and Euro amount from user input
    float yenCon = 108.81;               // USD to Yen conversion
    float euroCon = 0.84;                // USD to Euro conversion
 
    cout << "The current conversions from USD to Yen are " << endl;
            cout << "One USD converts to " << yenCon << " Yen." << endl << endl;
 
            cout << "The current conversions from USD to Euros are " << endl;
            cout << "One USD converts to " << euroCon << " Euros." << endl << endl;
 
            cout << "How many Dollars would you like to convert? ";
            cin >> Dollar;
 
            cout << endl;
 
            cout << setprecision(2) << fixed << showpoint;
 
            yenAmn = Dollar * yenCon;  // User input multiplied by Yen conversion
 
            eurAmn = Dollar * euroCon; // User input multiplied by Euro conversion
 
            cout << Dollar << " dollars into Yen is " << yenAmn << "." << endl;
            cout << endl;
 
            cout << Dollar << " dollars into Euros is " << eurAmn << "." << endl;
            cout << endl;
 
 
    return 0;
}