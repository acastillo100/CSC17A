//Alex Castillo                  CSC-17A                  Chapter 3, P. 144, #12
//
/*****************************************************************************
 *
 * Convert Celsius to Fahrenheit  
 * __________________________________________________________________________
 * 
 * This program accepts user input a number for the degrees of temperature in 
 * Celsius and outputs the number into the appropriate degree in Fahrenheits. 
 * 
 * Computation is based on the formula:
 * 
 * Far = (9/5)Cel + 32  
 * __________________________________________________________________________
 * 
 * INPUT
 * Cal                                      : The degrees in Celsius 
 * 
 * OUTPUT
 * Far                                      : The degrees in Fahrenheit
 ****************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;
 
/*
 * 
 */
int main(int argc, char** argv) {
 
    int Cal, Far;
 
    cout << "Please enter the degrees in Celsius so it may be converted into" << endl;
            cout << " Fahrenheit." << endl << endl;
 
            cin >> Cal;
 
            cout << endl;
 
            Far = ((Cal*9)/5) + 32;
 
            cout << Cal << " in Celsius is " << Far << " in Fahrenheit." << endl;
 
    return 0;
}