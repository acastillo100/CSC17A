// Alex Castillo   		 CSC-17A	          Chapter 4, P. 225, #21
//
/************************************************************************
 *
 * GEOMETRY CALCULATOR
 * ______________________________________________________________________
 * The program asks the user to choose either to do the area of 
 * a circle, rectangle, or triangle using a menu. After choosing a number
 * 1-3 the user inputs their selection the program outputs an answer.
 *
 * Computation is based on the formula: 
 * areaCircle = PI * pow(radius, 2.0)
 * areaRect = length * width
 * triArea = triBase* triHeight * .5
 * ______________________________________________________________________
 * INPUT
 *   radius    : radius of the circle
 *   length    : length of the rectangle
 *   width     : width of the rectangle
 *   triBase   : base of the triangle
 *   triHeight : height of the triangle
 *
 * OUTPUT
 *   triArea    : area of the triangle
 *   areaRect   : area of the rectangle
 *   areaCircle : area of the circle
 *
 ***********************************************************************/
#include <iostream>
#include <cmath>  
using namespace std;
 
int main() 
{
//  DECLARE VARIABLES
	int choice;				// Lets user select option on menu
	float areaCircle, radius;		// area and radius for the circle
	int length, width, areaRect;     	// length, width, and area of rectangle
	int triBase, triHeight, triArea;	// base, height, and area of triangle
 
//  CONSTANT FOR RADIUS
	const float PI = 3.14159;
 
	cout << "Welcome" << endl;
        
        
        do
        {
            //  START CALCULATOR
            cout << "Choose an area to calculate from 1-4" << endl;	
            cout << "1) Calculate area of a Circle" << endl;
            cout << "2) Calculate area of a Rectangle" << endl;
            cout << "3) Calculate area of a Triangle" << endl;
            cout << "4) Quit" << endl;
            cin >> choice;
            cout << endl;		
 
//  If/Else If Statement	
            if (choice == 1)
            {
                //  CIRCLE OUTPUT AND USER INPUT 
		cout << "You picked 1, calculate area of a circle\n " << endl;
		cout << "Please enter the radius of circle:\n " << endl;
		cin  >> radius;
 
                //  COMPUTE AREA OF CIRCLE BASED ON USER INPUT 
		areaCircle = PI * pow(radius, 2.0);
		cout << "The area of the circle is " << areaCircle << endl;
            }
 
            else if (choice == 2)
            {
 
   		//RECTANGLE OUTPUT AND USER INPUT 
		cout << "You picked number 2, calculate area of rectangle\n" << endl;
		cout << "Please enter the length of the rectangle: " << endl;
		cin  >> length;
                cout << endl;
                cout << "Please enter the width of the rectangle: " << endl;
                cin  >> width;
                cout << endl;
 
                //COMPUTE AREA OF RECTANGLE BASED ON USER INPUT 
                areaRect = length * width;
 
                //OUTPUT TOTAL AREA OF RECTANGLE
                cout << "The area of the rectangle is " << areaRect << endl;
                cout << endl;
 
            }
 
            else if (choice == 3)
            {
 
                    //  TRIANGLE OUTPUT AND USER INPUT
                        cout << "You picked number 3, calculate area of a triangle\n" << endl;
                        cout << "Please enter the triangle's base\n" << endl;
                        cin  >> triBase;
                        cout << "Please enter the triangle's height\n" << endl;
                        cin  >> triHeight;
 
                //  COMPUTE TRIANGLE AREA
                        triArea = triBase * triHeight * .5;
 
                //  OUTPUT TOTAL AREA OF TRIANGLE 
            	cout << "\nThe total area of the triangle is " << triArea << endl;
 
 
            }
 
            else (choice == 4);
            {
 		cout << "Quit" << endl;
            }
        }while(choice !=4);
    return 0;
}