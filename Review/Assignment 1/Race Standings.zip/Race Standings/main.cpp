// Alex Castillo   		CSC-17A			  Chapter 4, P. 223, #14
//
/************************************************************************
 *
 * PRESENT RACE RESULTS
 * ______________________________________________________________________
 * The program asks the user for the names and times of three racers who
 * finished a race. The program then displays who placed in first,
 * second, and third in the race when it was completed.
 *
 * ______________________________________________________________________
 * INPUT
 *   nameOne   : Name of the first runner
 *   nameTwo   : Name of the second runner
 *   nameThree : Name of the third runner
 *   timeOne   : Time it took for the first runner to finish
 *   timeTwo   : Time it took for the second runner to finish
 *   timeThree : Time it took for the third runner to finish
 *
 ***********************************************************************/
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
int main()
{
    string nameOne;           // INPUT  - Name of first runner
    string nameTwo;           // INPUT  - Name of second runner
    string nameThree;         // INPUT  - Name of third runner
    double raceOne;           // INPUT  - Time of the first runner
    double raceTwo;           // INPUT  - Time of the second runner
    double raceThree;         // INPUT  - Time of the third runner

// User input 	
	cout << "  What was the name of the first runner?\n ";
	cin >> nameOne;
	cin.ignore(256, '\n');
        
	cout << " What was the time of the first runner in seconds?\n ";
	cin >> raceOne;
	cin.ignore(256, '\n');
        
	cout << " What was the name of the second runner?\n ";
	cin >> nameTwo;
	cin.ignore(256, '\n');
        
	cout << " What was the time of the second runner in seconds?\n ";
	cin >> raceTwo;
	cin.ignore(256, '\n');
        
	cout << " What was the name of the third runner? \n";
	cin >> nameThree;
	cin.ignore(256, '\n');
        
	cout << "  What was the time of the third runner in seconds? \n";
	cin >> raceThree;
	cin.ignore(256, '\n');

// Decimal Precision
    cout << fixed << showpoint << setprecision(2);
   
// If statement to decide different outcomes
	if ((raceOne < raceTwo) && (raceOne < raceThree))
	{
		cout << "1st place is: " << nameOne << endl;
		if (raceTwo < raceThree)
		{
			cout << "2nd place is: " << nameTwo << endl;
			cout << "3rd place is: " << nameThree << endl;
		}
		else
		{
			cout << "2nd place is: " << nameThree << endl;
			cout << "3rd place is: " << nameTwo << endl;
		}
	}
	else if ((raceTwo < raceThree) && (raceTwo < raceOne))
	{
		cout << "1st place is: " << nameTwo << endl;
		if (raceOne < raceThree)
		{
			cout << "2nd place is: " << nameOne << endl;
			cout << "3rd place is: " << nameThree << endl;
		}
		else
		{
			cout << "2nd place is: " << nameThree << endl;
			cout << "3rd place is: " << nameOne << endl;
		}
	}
	else
	{
		cout << "1st place is: " << nameThree << endl;
		if (raceTwo < raceOne)
		{
			cout << "2nd place is: " << nameTwo << endl;
			cout << "3rd place is: " << nameOne << endl;
		}
		else
		{
			cout << "2nd place is: " << nameOne << endl;
			cout << "3rd place is: " << nameTwo << endl;
		}
	}
return 0;
}
