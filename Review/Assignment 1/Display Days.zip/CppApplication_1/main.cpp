//Alex Castillo                  CSC-17A                  Chapter 4, P. 221, #10
//
/*****************************************************************************
 *
 * Display Days 
 * __________________________________________________________________________
 * 
 * This program accepts a user inputed number for the month that corresponds to
 * the real life equivalent alongside the year. The program then outputs the
 * numbers of days in the requested month, accounting for leap years for
 * Febuary as well.
 * 
 * Computation for leap year is based on the formula:
 * 
 * year % 100 == 0 && year % 400 == 0
 * __________________________________________________________________________
 * 
 * INPUT
 * Month                                    : The month requested
 * Year                                     : The year requested
 * 
 * OUTPUT
 * Day                                      : The days in the requested month and year
 ****************************************************************************/
 
#include <iostream>
#include <iomanip>
#include <cstdlib>
 
using namespace std;
 
int main(int argc, char** argv) 
{
 
    int day, month, year;
 
    cout << "Please enter a number 1-12 corresponding with a month and year" << endl;
    cout << "  and I will tell you how many days are in that month." << endl;
 
    cout << "Please enter the month (1-12): ";
 
    cin >> month;
 
    cout << endl << endl;
 
    cout << "Please enter the year: " << endl;
 
    cin >> year;
 
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) 
	{
	  day = 31;
	}
    else if (month == 4 || month == 6 || month == 9 || month == 11)
	{
		day = 30;
	}
    else
	{
		day = 28;
	}
 
 
    if (month == 2 && year % 100 == 0 && year % 400 == 0)
    {
    	day = day + 1;
    }
 
    cout << endl << endl;
 
    cout << month << endl;
 
    cout << day << endl;
 
    cout << year << endl;
 
    return 0;
}