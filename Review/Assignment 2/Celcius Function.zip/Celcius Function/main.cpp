#include <iomanip>
#include <iostream>
#include <cstdlib>

using namespace std;

//int Celsius (&int Fah)
//{
//    int Cel = (5/9)*(Fah-32);
//    return Cel;
//}

void Celsius(int &Fah);
void Celsius2(int &Fah);

int main(int argc, char** argv) 
{
    int Faheit;
    int Cel;
    
    cout << "Please enter the temperature in Fahrenheit: ";
    cin >> Faheit;
    
    cout << "\nThis is the temperature in Fahrenheit: " << Faheit << endl;
    
    Celsius(Faheit);
    
    Faheit = 0;
    
    Celsius2(Faheit);
    
    
    
//    cout << "This is the temperature in Celsius: " << Cel << endl;

    return 0;
}

void Celsius (int &Fah)
{
   int Cel;
   cout << "\nThis is the temperature in F: " << Fah << endl;
   Cel = ((5*(Fah-32))/9);
   cout << "\nThis is the temperature in Celsius: " << Cel << endl << endl;
}

void Celsius2(int &Fah)
{
    
    cout << "Fahrenheit" << setw(10) << "Celsius" << endl;
    for (int i = 0; i <= 20; i++)
    {
        Fah=i;
        int Cel = ((5*(Fah-32))/9);
        cout << Fah << setw(17) << Cel << endl;
    }
}

//int Celsius (int &Fah)
//{
//    int Cel = (5/9)*(Fah-32);
//    return Cel;
//}

