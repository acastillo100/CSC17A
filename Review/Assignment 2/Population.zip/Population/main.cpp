//Alex Castillo                  CSC-17A                  Chapter 5, P. 295, #11
//
/*****************************************************************************
 *
 * Calculate Population Size  
 * __________________________________________________________________________
 * 
 * This program will predict the size of a population of organisms. The program
 * asks the user for the starting number of organisms, their average daily
 * population increase, as a percentage, and the number of days they will
 * multiply. A loop then displays the size of the population for each day.
 
 * 
 * Computation is based on the formula:
 *  
 * __________________________________________________________________________
 * 
 * INPUT
 * Organms                                  : Starting Number of Organisms
 * popIncs                                  : Daily population increase
 * days                                     : Days of organisms multiplying
 * 
 * OUTPUT
 * orgSize                                  : The size of the organisms
 ****************************************************************************/
 
#include <iostream>
#include <iomanip>
#include <cstdlib>
 
using namespace std;
 
int main(int argc, char** argv) {
 
    int Organms, days, orgSize;
    float popIncs;
 
 
    cout << "Please enter the starting size, more than one, of the population: ";
    cin >> Organms;
    cout << endl;
    while (Organms <= 1)
    {
        cout << "\nYou entered an incorrect number of organisms. Please ";
        cout << "try again: ";
        cin >> Organms;
    }
 
    cout << "The number of organisms is "<< Organms << endl;
    
    cout << "Please enter the decimal percentage for the average population increase: ";
    
    cin >> popIncs;
    
    while (popIncs < 0)
    {
        cout << "\nYou entered an negative percentage. Please try again: ";
        cin >> popIncs;
    }
    
    cout << setprecision(2) << fixed << showpoint;
    cout << "The decimal percentage is "<< popIncs << endl;
    
    cout << "\nHow many days will this population multiply for?: ";
    cin >> days;
    
    while (days <= 0)
    {
        cout << "\nYou can not have zero or negative days, please try again: ";
        cin >> days;
    }
    
    cout << "\nThe number of days is "<< days << endl;
    
    for (int i = 1; i <= days; i++)
    {
        orgSize = Organms * popIncs;
        cout << " \nThe number of organisms for day " << i << " is: " << Organms;
        Organms = orgSize + Organms;
        cout << endl;
    }
 
    return 0;
}