//Alex Castillo			       CSC5			    Chapter 8, P.487. #2
//
/*******************************************************************
 * 
 *    Binary String Search
 * This program modifies the binarySearch function presented earlier this chapter 
 * so the program searches for an array of strings instead of an array of ints. 
 * The array is sorted before the binary search and accepts user input for the
 * string.
 * 
*/
//
#include <iostream>
#include <string>
using namespace std;

// Function prototype
int binarySearch(string[], int, string);
void selectionSort(string[], int);
string getValue();

int main()
{
	const int NUM_NAMES = 20;      // Total number of names

	string names[NUM_NAMES] =
	{"Collins, Bill", "Smith, Bart", "Michalski, Joe", "Griffin, Jim",
	"Sanchez, Manny", "Rubin, Sarah", "Taylor, Tyrone", "Johnson, Jill",
	"Allison, Jeff", "Moreno, Juan", "Wolfe, Bill", "Whitman, Jean",
	"Moretti, Bella", "Wu, Hong", "Patel, Renee", "Harrison, Rose",
	"Smith, Cathy", "Conroy, Pat", "Kelly, Sean", "Holland, Beth"};

	string value;             // String to be inserted after getValue
	int result;               // Value to test if string was found

	selectionSort(names, NUM_NAMES);  // Sorts the name list

	value = getValue();      // Collects user input for string

	result = binarySearch(names, NUM_NAMES, value);

	if (result == -1)
		cout << "Name is not in list.\n";
	else
		cout << names[result] << " was found in subscript #" << result << ".\n"; 

	return 0;
}
/*********************************************************************************
 *                                  selectionSort                                *
 * This function performs a selection sort on the string array.   *
 * This parameter size holds the number of elements in the array.                *
 *********************************************************************************/
void selectionSort(string array[], int size)
{
	int startScan, minIndex;
	string minValue;

	for (int startScan = 0; startScan < (size - 1); startScan++)
	{
		minIndex = startScan;
		minValue = array[startScan];
		for (int index = 0; index < size; index++)
		{
			minValue = array[index];
			minIndex = index;
		}
		array[minIndex] = array[startScan];
		array[startScan] = minValue;
	}
}
/*********************************************************************************
 *                                    getValue                                   *
 * This function asks the user a string value and returns it.                    *
 *********************************************************************************/
string getValue()
{
	string input;
	cout << "Enter the name you would like to search for: ";
	getline(cin, input);
	return input;
}

/*********************************************************************************
 *                                 binarySearch                                  *
 * This function performs a binary search on a string array                      * 
 *********************************************************************************/
int binarySearch(string array[], int size, string value)
{
	int first = 0,						// First array element
		last = size - 1,				// Last array element
		middle,							// Midpoint of search
		position = -1;					// Position of search value
	bool found = false;					// Flag

	while (!found && first <= last)
	{
		middle = (first + last) / 2; 	// Calculate midpoint
		if (array[middle] == value)		// If value is found at mid
		{
			found = true;
			position = middle;
		}
		else if (array[middle] > value) // If value is in lower half
			last = middle - 1;
		else
			first = middle + 1;			// If value is in upper half
	}
	return position;	
}