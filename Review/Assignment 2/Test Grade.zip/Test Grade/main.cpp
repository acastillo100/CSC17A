//Alex Castillo 	        CSC-17A 	           Chapter 7, P. 446, #9
//
/******************************************************************
 *
 * GRADE A DRIVER'S LISCENSE EXAM
 * ________________________________________________________________
 * This program lets the user enter the answers for the test.
 * The program displays which questions the user got wrong or 
 * right and displays if they passed the exam. To pass the exam, 
 * user has to get 15 out of 20 questions correct.
 * ________________________________________________________________
 * INPUT
 *   testInput          : Input for the test
 * OUTPUT
 *   totalCorrect		: Total corrections of the answers
 * ***************************************************************/
 
#include <iostream>
#include <iomanip>
using namespace std;
 
int main() 
{
//	Declare variables	
	const int ANSWERS   = 20,
			  QUESTIONS = 20,
			  INPUT		= 20,
			  CORRECT   = 1;	
 
	int testNumber[QUESTIONS] = { 1, 2, 3, 4, 5, 6, 7, 8, 9,
								  10, 11, 12, 13, 14, 15,
								  16, 17, 18, 19, 20};
 
	char testAnswer[ANSWERS] = { 'B','D','A','A',
								 'C','A','B','A',
								 'C','D','B','C',
								 'D','A','D','C',
								 'C','B','D','A'};
	char testInput[INPUT];
	int totalCorrect = 0;		
	int count;

//	Prompt user for answers
	cout << "Enter an uppercase A, B, C or D for your answer:";
	for(count = 0; count < QUESTIONS; count++)
	{
 		cin >> testInput[count];
	}
 
	for(count = 0; count < QUESTIONS; count++)
	{
			if (testInput[count] != 'A' && testInput[count] != 'B' &&
				testInput[count] != 'C' && testInput[count] != 'D')
			{
				cout << "Please enter valid letter of A, B, C or D: " << endl;
				cin >> testInput[count];
			}
			// Comparing the right answers with an if
			if ( testInput[count] == testAnswer[count])
			{
				totalCorrect += CORRECT;
				cout << endl;
			}
	}

//	Output the test results
	cout << "You Scored " << totalCorrect << " out of 20 Questions" << endl;
 
	if (totalCorrect >= 15)
		cout<< "You Passed" << endl;
	else
		cout << "You Failed" << endl;
 
	cout << "Question #" 		<< setw(18) 
		 << "Correct Answer" 	<< setw(16) 
		 << "Your Answer \n";
 
	for (count = 0; count < QUESTIONS; count++)
		{
			cout << left;
			cout << setw(19) << testNumber[count] 
				 << setw(16) << testAnswer[count]
				 << setw(15) << testInput[count];
			cout << endl;
		}
 
	return 0;
}